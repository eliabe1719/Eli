<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include('../models/Model.php');
$model = new Model();
$pdo = $model->getConnect();

require_once('../configs/protected.php');

$nome = $_SESSION['usuario_nome'] ?? $_SESSION['empresa_nome'] ?? 'Nome não disponível';
$email = $_SESSION['usuario_email'] ?? $_SESSION['empresa_email'] ?? 'E-mail não disponível';
$cnpj = $_SESSION['empresa_cnpj'] ?? 'CNPJ não disponível';

$sql = "SELECT nome, nome_dono, email, nicho, logradouro, bairro, cidade, estado FROM camps LIMIT 1";
$result = $pdo->query($sql);
$camp = $result->fetch(PDO::FETCH_ASSOC);



?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../Imagens/favicon.png">
    <title>Sport Town</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #1a1a1a;
            color: #ffffff;
            line-height: 1.6;
            padding-bottom: 70px;
        }

        .profile-section {
            background: linear-gradient(135deg, #1a1a1a, #2d2d2d);
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 17, 17, 0.3);
            margin-bottom: 20px;
        }

        .profile-text strong {
            font-size: 20px;
            color: #fff;
            display: block;
            margin-bottom: 5px;
        }

        .profile-text small {
            color: #fff;
            font-size: 14px;
            display: block;
            margin-bottom: 3px;
        }

        .sair {
            color: #fff;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.3s ease;
            display: inline-block;
            margin-top: 10px;
        }

        .sair:hover {
            color: #fff;
            text-decoration: underline;
        }

        .btn-config {
            background-color: #2d2d2d;
            border: 1px solid rgba(255, 17, 17, 0.2);
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            transition: all 0.3s ease;
            text-align: left;
        }

        .btn-config:hover {
            background-color: #363636;
            border-color: rgb(255, 17, 17);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        .btn-config h5 {
            color: #fff;
            font-size: 16px;
            margin: 0;
        }

        .btn-config small {
            color: #fff;
            font-size: 12px;
        }

        .status-badge {
            background-color: rgba(255, 255, 255, 0.2) !important;
            color: #fff !important;
            font-size: 12px;
            padding: 5px 10px;
            border-radius: 20px;
        }

        .bottom-nav {
            background-color: #1a1a1a;
            border-top: 1px solid rgba(255, 17, 17, 0.3);
            box-shadow: 0 -4px 10px rgba(0, 0, 0, 0.2);
            position: fixed;
            bottom: 0;
            width: 100%;
            z-index: 1000;
        }

        .nav-link {
            text-decoration: none;
            color: #fff;
            transition: all 0.3s ease;
            padding: 8px 0;
        }

        .nav-link:hover {
            color: #fff;
        }

        .nav-link img {
            width: 24px;
            height: 24px;
            margin-bottom: 4px;
            transition: transform 0.3s ease;
        }

        .nav-link:hover img {
            transform: scale(1.1);
        }

        .nav-link small {
            font-size: 12px;
            display: block;
            margin-top: 4px;
            color: #fff;
        }

        @media (max-width: 768px) {
            .profile-section {
                padding: 15px;
            }

            .profile-text strong {
                font-size: 18px;
            }

            .btn-config {
                padding: 12px;
            }

            .btn-config h5 {
                font-size: 14px;
            }
        }
    </style>
</head>
<body class="bg-dark text-white pb-5">
    <div class="profile-section">
        <div class="profile-text">
         <strong><?= htmlspecialchars($nome) ?></strong><br>
           <small><?= htmlspecialchars($email) ?></small><br>
                
         <?php if (isset($_SESSION['empresa_cnpj'])): ?>
                    <small>CNPJ: <?= htmlspecialchars($cnpj) ?></small><br>
         <?php endif; ?>
    
    <a href="../login/logout.php" class="sair" style="color: #fff !important;"><small style="color: #fff !important;">Sair</small></a>
</div>
    </div>
    <!------------------------------------------------------------------------------------------------------------- -->
<br>
         <?php if (isset($_SESSION['tipo']) && $_SESSION['tipo'] === 'empresa'): ?>
    <button onclick="window.location.href='../cadastros/camps.php'" class="btn btn-light w-100 btn-config">
        <div>
            <h5 class="mb-1">Cadastrar Campeonatos</h5>
            <small class="text-muted" style="color: #fff !important;">TORNEIOS</small>
        </div>
    </button>
<?php endif; ?>

        <div class="position-relative">
            <button class="btn btn-light w-100 btn-config">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-1">Notificações</h5>
                        <small class="text-muted" style="color: #fff !important;">Receba alertas importantes</small>
                    </div>
                    <span class="badge bg-success status-badge" style="color: #fff !important;">ATIVADO</span>
                </div>
            </button>
        </div>

        <button class="btn btn-light w-100 btn-config">
            <div>
                <h5 class="mb-1">Cadastrar Anúncios</h5>
                <small class="text-muted" style="color: #fff !important;">ANÚNCIOS</small>
            </div>
        </button>
        
        <button class="btn btn-light w-100 btn-config">
            <div>
                <h5 class="mb-1">RIA 13 DE MAIO, IGUALDADE</h5>
                <small class="text-muted" style="color: #fff !important;">ENDEREÇO</small>
            </div>
        </button>
        <button class="btn btn-light w-100 btn-config">
            <div>
                <h5 class="mb-1">Segurança e Privacidade</h5>
                <small class="text-muted" style="color: #fff !important;">ENDEREÇO</small>
            </div>
        </button>

        <button class="btn btn-light w-100 btn-config">
            <div>
                <h5 class="mb-1">Suporte</h5>
                <small class="text-muted" style="color: #fff !important;">CONTATO</small>
            </div>
        </button>
    </div>
    <!-- ----------------------------------------------------------------------------------------------------------- -->
   
<div class="barra">
    <nav class="bottom-nav d-flex justify-content-around py-2">
        <a href="../painel.php" class="nav-link text-center">
            <div>
              <img src="../Imagens/home.png">
            </div>
            <small>Home</small>
        </a>
        <a href="search.php" class="nav-link text-center">
            <div>
                <img src="../Imagens/lupa.png" >
            </div>
            <small>Pesquisar</small>
        </a>
        <a href="#" class="nav-link text-center">
            <div>
              <img src="../Imagens/configuraçoes.png">
            </div>
            <small>Ajustes</small>
        </a>
    </nav>
</div>
<br>
<br>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
