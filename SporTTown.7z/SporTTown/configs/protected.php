<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['usuario_id']) && !isset($_SESSION['empresa_id'])) {
    die("Você não pode acessar esta página. <a href='../login/index.php'>Entrar</a>");
}
?>
