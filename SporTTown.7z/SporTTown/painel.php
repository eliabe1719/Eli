<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include('models/Model.php');
$model = new Model();
$pdo = $model->getConnect();
$camps = $model->getAllCamps();

require_once('configs/protected.php');

// Dados do usuário ou empresa logada
$nome = $_SESSION['usuario_nome'] ?? $_SESSION['empresa_nome'] ?? 'Nome não disponível';
$email = $_SESSION['usuario_email'] ?? $_SESSION['empresa_email'] ?? 'E-mail não disponível';
$cnpj = $_SESSION['empresa_cnpj'] ?? 'CNPJ não disponível';

// Consulta ao banco de dados para buscar informações de campeonatos
$sql = "SELECT nome, nome_dono, email, nicho, cep, logradouro, bairro, cidade, estado, cnpj, criado_em FROM camps";
$result = $pdo->query($sql);
$camps = $result->fetchAll(PDO::FETCH_ASSOC);

// Fechar a conexão
$pdo = null;
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="Imagens/favicon.png">
    <title>Sport Town</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"  rel="stylesheet">

    <style>
        /* Reset básico */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #1a1a1a;
            color: #ffffff;
            line-height: 1.6;
            padding-bottom: 70px; /* Espaço para navbar inferior */
        }

        /* Barra de perfil */
        .profile-section {
            background: linear-gradient(135deg, #1a1a1a, #2d2d2d);
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 40, 40, 0.3);
        }

        .profile-text strong {
            font-size: 20px;
            display: block;
            margin-bottom: 5px;
        }

        .profile-text small {
            font-size: 14px;
            color: #aaa;
        }

        .sair {
            color: #ff4d4d;
            text-decoration: none;
            font-size: 14px;
            transition: color 0.3s ease;
        }

        .sair:hover {
            text-decoration: underline;
            color: #ff6b6b;
        }

        /* Carrossel */
        .carousel-inner img {
            object-fit: cover;
            height: 250px;
            border-radius: 10px;
        }

        /* Cards de campeonatos */
        .camp-card {
            background-color: #2d2d2d;
            padding: 8px;
            border-radius: 6px;
            margin-bottom: 10px;
            box-shadow: 0 1px 4px rgba(0, 0, 0, 0.2);
            transition: transform 0.3s ease;
            border: 1px solid rgba(255, 40, 40, 0.1);
        }

        .camp-card:hover {
            transform: translateY(-2px);
            border-color: rgba(255, 40, 40, 0.3);
        }

        .camp-card h5 {
            font-size: 14px;
            margin-bottom: 4px;
            color: rgb(255, 40, 40);
        }

        .camp-card p {
            font-size: 11px;
            color: #e0e0e0;
            margin-bottom: 2px;
            line-height: 1.3;
        }

        .camp-card small {
            font-size: 10px;
            color: #b0b0b0;
        }

        /* Navegação inferior */
        /* Estilo geral para o rodapé */
.bottom-nav {
    box-shadow: 0 -4px 10px rgba(0, 0, 0, 0.2); /* Sombra sutil */
    background-color: #1a1a1a; /* Fundo escuro premium */
    z-index: 1000;
    border-top: 1px solid rgba(255, 40, 40, 0.3);
}

/* Ícones na barra de navegação */
.nav-icon {
    width: 28px;
    height: 28px;
    transition: transform 0.3s ease, filter 0.3s ease; /* Animação suave */
    filter: grayscale(100%); /* Inicia em tons de cinza */
}

.nav-icon:hover {
    transform: scale(1.1); /* Aumenta o tamanho ao passar o mouse */
    filter: grayscale(0%); /* Remove o filtro cinza */
}

/* Texto abaixo dos ícones */
.nav-link small {
    font-size: 12px;
    color: #ffffff;
    margin-top: 4px;
    display: block;
    transition: color 0.3s ease; /* Transição suave para o texto */
}

.nav-link:hover small {
    color: rgb(255, 40, 40); /* Altera a cor do texto ao passar o mouse */
}

/* Remover sublinhado dos links */
.nav-link {
    text-decoration: none;
    color: inherit;
}
        /* Responsividade */
        @media (max-width: 576px) {
            .profile-text strong {
                font-size: 18px;
            }

            .camp-card h5 {
                font-size: 16px;
            }

            .camp-card p {
                font-size: 12px;
            }
        }

       /* Estilo geral para o cabeçalho */
.profile-section {
    background: linear-gradient(135deg, #1c1c1c, #2c3e50); /* Gradiente escuro elegante */
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2); /* Sombra sutil */
    border-bottom: 1px solid rgba(255, 255, 255, 0.1); /* Linha divisória */
}

/* Logo/Ícone */
.profile-section img {
    
    width: 40px;
    height: 40px;
    object-fit: cover;
    border-radius: 50%; /* Formato circular */
    transition: transform 0.3s ease; /* Animação suave */
}

.profile-section img:hover {
    transform: scale(1.1); /* Aumenta o tamanho ao passar o mouse */
}

/* Nome e informações */
.profile-section strong {
    font-size: 18px;
    color: #f39c12; /* Amarelo vibrante */
    transition: color 0.3s ease; /* Transição suave */
}

.profile-section strong:hover {
    color: #ffca28; /* Amarelo mais claro ao passar o mouse */
}

.profile-section small {
    font-size: 14px;
    color: #aaa; /* Cinza claro */
    margin-bottom: 5px;
    display: block;
}

/* Botão "Sair" */
.btn-outline-danger {
    font-size: 12px;
    padding: 5px 10px;
    border: 1px solid rgb(255, 40, 40);
    color: rgb(255, 40, 40);
    transition: background-color 0.3s ease, color 0.3s ease;
}

.btn-outline-danger:hover {
    background-color: rgb(255, 40, 40);
    color: #ffffff;
}
.text-decoration-none text-muted {
    font-size: 18px;
    padding; auto;
    color: #ff4d4d;
}
.text-muted d-block{
font-size: 18px;
    color: #f39c12; /* Amarelo vibrante */
    transition: color 0.3s ease; /* Transição suave */
}

/* Responsividade */
@media (max-width: 576px) {
    .profile-section strong {
        font-size: 16px;
    }

    .profile-section small {
        font-size: 12px;
        
    }

    .btn-outline-danger {
        font-size: 10px;
        padding: 3px 8px;
    }

}

    </style>
</head>
<body>

    <!-- Perfil do Usuário -->
<header class="profile-section py-3" style="background: linear-gradient(135deg, #1c1c1c, #2c3e50); border-bottom: 1px solid rgb(255, 40, 40);">
    <div class="container">
        <div class="row align-items-center">
            <!-- Logo/Ícone à Esquerda -->
            <div class="col-auto">
                <img src="Imagens/favicon.png" alt="Logo" class="rounded-circle" style="width: 40px; height: 40px;">
            </div>

            <!-- Informações Centralizadas -->
            <div class="col text-center">
                <strong class="d-block" style="color: rgb(255, 17, 17);"><?= htmlspecialchars($nome) ?></strong>
                <!-- Email do Usuário -->
<small class="d-block mb-2">
    <a href="mailto:<?= htmlspecialchars($email) ?>" class="text-decoration-none" style="color:rgb(255, 255, 255);">
        <?= htmlspecialchars($email) ?>
    </a>
</small>
                <?php if (isset($_SESSION['empresa_cnpj'])): ?>
                    <small class="d-block mb-2">
                        <a href="#" class="text-decoration-none" style="color:rgb(255, 255, 255);">
                            CNPJ: <?= htmlspecialchars($cnpj) ?>
                        </a>
                    </small>
                <?php endif; ?>
            </div>

            <!-- Botão "Sair" à Direita -->
            <div class="col-auto">
                <a href="login/logout.php" class="btn btn-sm btn-outline-danger">Sair</a>
            </div>
           
        </div>
    </div>
</header>



    <!-- Carrossel -->
    <div id="carouselExampleSlidesOnly" class="carousel slide mt-4" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="Imagens/1.png" class="d-block w-100" alt="Slide 1">
            </div>
            <div class="carousel-item">
                <img src="Imagens/2.png" class="d-block w-100" alt="Slide 2">
            </div>
            <div class="carousel-item">
                <img src="Imagens/Zenir.jpg" class="d-block w-100" alt="Slide 3">
            </div>
        </div>
    </div>

    <!-- Lista de Campeonatos -->
    <div class="container mt-4">
        <?php if (empty($camps)): ?>
            <p class="text-center text-muted">Nenhum campeonato cadastrado.</p>
        <?php else: ?>
            <?php foreach ($camps as $camp): ?>
                <div class="camp-card">
                    <div class="row align-items-center">
                        <!-- Coluna 1 -->
                        <div class="col-md-4">
                            <h5><?= htmlspecialchars($camp['nome_dono']) ?></h5>
                            <p><?= htmlspecialchars($camp['email']) ?></p>
                            <p><?= htmlspecialchars($camp['cnpj']) ?></p>
                        </div>

                        <!-- Coluna 2 -->
                        <div class="col-md-6">
                            <h5><?= htmlspecialchars($camp['nome']) ?></h5>
                            <p>
                                Nicho: <?= htmlspecialchars($camp['nicho']) ?><br>
                                Endereço: <?= htmlspecialchars($camp['logradouro']) ?>, <?= htmlspecialchars($camp['bairro']) ?><br>
                                Cidade: <?= htmlspecialchars($camp['cidade']) ?>/<?= htmlspecialchars($camp['estado']) ?>
                            </p>
                            <small>
                                Cadastrado em: <?= date('d/m/Y H:i', strtotime($camp['criado_em'])) ?>
                            </small>
                        </div>

                        <!-- Coluna 3 -->
                        <div class="col-md-2 text-end">
                            <img src="Imagens/logo-camp.png" alt="Logo" style="width: 50px; height: 50px;">
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Navegação inferior -->
<nav class="bottom-nav fixed-bottom d-flex justify-content-around py-3" style="background-color: #1c1c1c; border-top: 1px solid rgba(255, 255, 255, 0.1);">
    <a href="#" class="nav-link text-center text-decoration-none">
        <div>
            <img src="Imagens/home.png" alt="Home" class="nav-icon">
        </div>
        <small class="text-white">Home</small>
    </a>
    <a href="Ações/search.php" class="nav-link text-center text-decoration-none">
        <div>
            <img src="Imagens/lupa.png" alt="Pesquisar" class="nav-icon">
        </div>
        <small class="text-white">Pesquisar</small>
    </a>
    <a href="Ações/config.php" class="nav-link text-center text-decoration-none">
        <div>
            <img src="Imagens/configuraçoes.png" alt="Ajustes" class="nav-icon">
        </div>
        <small class="text-white">Ajustes</small>
    </a>
</nav>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> 
</body>
</html>