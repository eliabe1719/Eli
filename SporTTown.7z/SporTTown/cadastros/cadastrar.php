<?php
session_start(); // Garante que a sessão esteja iniciada
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../Imagens/favicon.png">
    <title>Cadastro</title>
    <style>
        :root {
            --primary: #1a1a1a;
            --secondary: #ff1111;
            --dark: #2d2d2d;
            --light: #f8f9fa;
            --gray: #b0b0b0;
            --success: #155724;
            --error: #721c24;
            --shadow: 0 4px 24px rgba(0,0,0,0.5);
            --transition: all 0.3s ease;
        }
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        body {
            background: linear-gradient(135deg, #1a1a1a, #2d2d2d 80%);
            color: var(--light);
            padding: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container {
            max-width: 400px;
            width: 100%;
            margin: 0 auto;
            background: var(--dark);
            border-radius: 15px;
            box-shadow: var(--shadow);
            overflow: hidden;
            animation: fadeIn 0.8s ease-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        header {
            background: linear-gradient(to right, var(--primary), #363636);
            color: var(--light);
            padding: 25px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        header h1 {
            font-size: 2rem;
            margin-bottom: 10px;
            position: relative;
            z-index: 1;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }
        header p {
            font-size: 1.1rem;
            opacity: 0.9;
            max-width: 600px;
            margin: 0 auto;
            position: relative;
            z-index: 1;
        }
        .content {
            padding: 30px;
        }
        .form-section {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px dashed #444;
        }
        .form-section h2 {
            color: var(--secondary);
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid var(--secondary);
            display: flex;
            align-items: center;
        }
        .form-section h2 i {
            margin-right: 10px;
            font-size: 1.5rem;
        }
        .form-group {
            margin-bottom: 25px;
            position: relative;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--light);
            display: flex;
            align-items: center;
        }
        label i {
            margin-right: 8px;
            font-size: 1.1rem;
        }
        .required::after {
            content: " *";
            color: var(--secondary);
        }
        input, select {
            width: 100%;
            padding: 14px;
            border: 2px solid #444;
            border-radius: 8px;
            font-size: 16px;
            transition: var(--transition);
            background-color: #232323;
            color: var(--light);
        }
        input:focus, select:focus {
            border-color: var(--secondary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(255, 17, 17, 0.15);
            background-color: #181818;
        }
        .btn {
            background: linear-gradient(to right, var(--secondary), #a00);
            color: #fff !important;
            border: none;
            padding: 16px 30px;
            font-size: 18px;
            font-weight: 600;
            border-radius: 8px;
            cursor: pointer;
            width: 100%;
            transition: var(--transition);
            text-transform: uppercase;
            letter-spacing: 1px;
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
            overflow: hidden;
        }
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
            background: linear-gradient(to right, #a00, var(--secondary));
            color: #fff !important;
        }
        .btn:active {
            transform: translateY(0);
            color: #fff !important;
        }
        .btn::after {
            content: "";
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent);
            transition: 0.5s;
        }
        .btn:hover::after {
            left: 100%;
        }
        .notification {
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
            text-align: center;
            font-weight: 500;
            display: none;
            animation: slideIn 0.3s ease-out;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .success {
            background-color: #232;
            color: #7fff7f;
            border: 1px solid #393;
        }
        .error {
            background-color: #400;
            color: #ff7f7f;
            border: 1px solid #a00;
        }
        .password-toggle {
            position: absolute;
            right: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
            cursor: pointer;
            font-size: 1.2rem;
            height: 1.2em;
            display: flex;
            align-items: center;
        }
        @media (max-width: 500px) {
            .container {
                padding: 0;
                border-radius: 0;
                box-shadow: none;
            }
            header h1 {
                font-size: 1.3rem;
            }
            .content {
                padding: 12px;
            }
            .btn {
                padding: 12px 10px;
                font-size: 16px;
            }
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <h1><i class="fas fa-user-plus"></i> Cadastro de Usuário</h1>
            <p>Preencha os dados abaixo para criar sua conta</p>
        </header>
        <div class="content">
            <?php if (isset($_GET['sucesso']) && $_GET['sucesso'] == 1): ?>
                <div class="notification success" style="display:block;">Usuário cadastrado com sucesso!</div>
            <?php endif; ?>
            <form id="cadastroForm" action="../router.php?rota=cadastrar" method="POST">
                <div class="form-section">
                    <h2><i class="fas fa-user"></i> Dados do Usuário</h2>
                    <div class="form-group">
                        <label for="nome" class="required"><i class="fas fa-user"></i> Nome</label>
                        <input type="text" id="nome" name="nome" placeholder="Nome" maxlength="200" required>
                    </div>
                    <div class="form-group">
                        <label for="email" class="required"><i class="fas fa-envelope"></i> Email</label>
                        <input type="text" id="email" name="email" placeholder="Email" maxlength="500" required>
                    </div>
                    <div class="form-group">
                        <label for="senha" class="required"><i class="fas fa-lock"></i> Senha</label>
                        <div style="position:relative;">
                            <input type="password" id="senha" name="senha" placeholder="Senha" minlength="6" maxlength="100" required style="padding-right:40px;">
                            <i class="fas fa-eye password-toggle" id="togglePassword"></i>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn">
                    <i class="fas fa-check-circle"></i> Cadastrar
                </button>
                <br>
                <button type="button" class="btn" onclick="window.location.href='../login/index.php'">
                    <i class="fas fa-arrow-left"></i> Voltar ao Menu
                </button>
            </form>
            <div id="notification" class="notification"></div>
        </div>
    </div>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const togglePassword = document.getElementById('togglePassword');
        const passwordInput  = document.getElementById('senha');
        const form           = document.getElementById('cadastroForm');
        // Toggle mostrar/ocultar senha
        if (togglePassword && passwordInput) {
            togglePassword.addEventListener('click', function() {
                const type = passwordInput.type === 'password' ? 'text' : 'password';
                passwordInput.type = type;
                togglePassword.classList.toggle('fa-eye');
                togglePassword.classList.toggle('fa-eye-slash');
            });
        }
        // Envio do formulário com validação
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            hideNotification();
            const nome  = document.getElementById('nome')?.value.trim() || '';
            const email = document.getElementById('email')?.value.trim() || '';
            const senha = passwordInput?.value || '';
            if (!nome) {
                showNotification('Nome é obrigatório!', 'error');
                return;
            }
            if (!email || !/^\S+@\S+\.\S+$/.test(email)) {
                showNotification('Email inválido!', 'error');
                return;
            }
            if (senha.length < 6) {
                showNotification('A senha deve ter pelo menos 6 caracteres.', 'error');
                return;
            }
            this.submit();
        });
        // Funções de notificação
        function showNotification(msg, type) {
            const n = document.getElementById('notification');
            if (!n) return;
            n.textContent = msg;
            n.className   = `notification ${type}`;
            n.style.display = 'block';
            n.scrollIntoView({ behavior: 'smooth', block: 'center' });
            if (type === 'success') setTimeout(() => n.style.display = 'none', 5000);
        }
        function hideNotification() {
            const n = document.getElementById('notification');
            if (n) n.style.display = 'none';
        }
    });
</script>
</body>
</html>