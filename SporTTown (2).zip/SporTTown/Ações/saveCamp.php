<?php
require_once __DIR__ . '/../controllers/Controller.php';
$controller = new Controller();
$campeonatos = $controller->listar();
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Lista de Campeonatos</title>
</head>
<body>
    <h2>Lista de Campeonatos</h2>

    <?php if (!empty($campeonatos)): ?>
        <table border="1">
            <tr>
                    <th>Nome do campeonato</th>
                    <th>Nome do dono</th>
                    <th>Modalidade</th>
                    <th>Endereço</th>
                </tr>
                <?php foreach ($campeonatos as $campeonato): ?>
                <tr>
                    <td><?= htmlspecialchars($campeonato->nome) ?></td>
                    <td><?= htmlspecialchars($campeonato->nome_dono) ?></td>
                    <td><?= htmlspecialchars($campeonato->nicho) ?></td>
                    <td><?= htmlspecialchars($campeonato->logradouro) ?></td>
                        <td>
                    <a href="/SporTTown/router.php?rota=deletar&nome=<?= urlencode($campeonato->nome) ?>" 
   onclick="return confirm('Tem certeza que deseja excluir este campeonato?');">
   Excluir
</a>
                </td>
                        <td>
            <a href="/SporTTown/router.php?rota=formAtualizar&nome=<?= urlencode($campeonato->nome) ?>">
                Atualizar
            </a>
        </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>Nenhum campeonato cadastrado.</p>
    <?php endif; ?>

    <br>
    <button onclick="window.location.href='/SporTTown/Ações/config.php'">
    Voltar
</button>
</body>
</html>