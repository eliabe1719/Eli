<?php
require_once('../models/Model.php');
require_once '../controllers/Controller.php';
$controller = new Controller();
$campeonatos = $controller->listar();
$nomePesquisa = $_GET['nome'] ?? '';
$campeonatos = $nomePesquisa ? $controller->buscarPorNome($nomePesquisa) : $controller->listar();
$nichoSelecionado = $_GET['nicho'] ?? '';
$model = new Model();
$pdo = $model->getConnect();

if (!empty($nichoSelecionado)) {
    $stmt = $pdo->prepare("SELECT * FROM camps WHERE nicho = :nicho");
    $stmt->bindParam(':nicho', $nichoSelecionado);
} else {
    $stmt = $pdo->prepare("SELECT * FROM camps");
}

$stmt->execute();
$camps = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../Imagens/favicon.png">
    <title>Sport Town</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #1a1a1a;
            color: #ffffff;
            line-height: 1.6;
            padding-bottom: 70px;
        }

        .search-container {
            background: #23243a;
            padding: 20px;
            border-bottom: 1px solid rgba(255, 17, 17, 0.13);
            margin-bottom: 20px;
            border-radius: 14px;
        }

        #searchInput {
            width: 100%;
            padding: 12px;
            border: 1.5px solid rgba(255, 17, 17, 0.13);
            border-radius: 8px;
            background-color: #181818;
            color: #fff;
            margin-bottom: 15px;
            transition: none;
        }

        #searchInput:focus {
            outline: none;
            border-color: #ff1111;
            box-shadow: none;
        }

        #searchInput::placeholder {
            color: #b0b0b0;
        }

        label {
            color: #e0e0e0;
            margin-bottom: 8px;
            display: block;
        }

        .form-select {
            background-color: #181818;
            color: #fff;
            border: 1.5px solid rgba(255, 17, 17, 0.13);
            border-radius: 8px;
            padding: 8px 12px;
            transition: none;
        }

        .form-select:focus {
            border-color: #ff1111;
            box-shadow: none;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin: 20px 0;
            background-color: #2d2d2d;
            border-radius: 8px;
            overflow: hidden;
        }

        th {
            background-color: #23243a;
            color: #ff1111;
            padding: 12px;
            text-align: left;
            font-weight: 700;
            border-bottom: 2px solid rgba(255, 17, 17, 0.18);
        }

        td {
            padding: 12px;
            border-bottom: 1px solid #23243a;
            color: #e0e0e0;
        }

        tr:hover {
            background-color: #23243a;
        }

        #error {
            color: rgb(255, 17, 17);
            margin-top: 10px;
            font-size: 14px;
        }

        .bottom-nav {
            background: #1a1a1a;
            border-top: 1.5px solid rgba(255, 17, 17, 0.18);
            box-shadow: none;
            z-index: 1000;
            position: fixed;
            bottom: 0;
            width: 100%;
            backdrop-filter: none;
            display: flex;
            justify-content: space-around;
            align-items: center;
        }

        .nav-link {
            text-decoration: none;
            color: #e0e0e0;
            transition: all 0.3s ease;
        }

        .nav-link:hover {
            color: rgb(255, 17, 17);
        }

        .nav-link img {
            width: 32px;
            height: 32px;
            margin-bottom: 4px;
            transition: none;
            filter: none;
        }

        .nav-link:hover img {
            transform: none;
            filter: none;
        }

        .nav-link small {
            font-size: 13px;
            color: #fff;
            margin-top: 4px;
            display: block;
            font-weight: 500;
        }

        @media (max-width: 768px) {
            .search-container {
                padding: 15px;
            }

            #searchInput {
                padding: 10px;
            }

            th, td {
                padding: 10px;
                font-size: 14px;
            }
            .form-select {
                width: 100% !important;
                min-width: 0;
            }
        }
        @media (max-width: 600px) {
            .search-container {
                padding: 10px;
            }
            #searchInput {
                font-size: 1rem;
            }
            .form-select {
                font-size: 1rem;
            }
            .bottom-nav {
                font-size: 0.95rem;
                padding: 0.3rem 0;
                width: auto;
                max-width: none;
            }
            .nav-link img {
                width: 20px;
                height: 20px;
            }
        }
        .table-responsive {
            width: 100%;
            overflow-x: auto;
        }
    </style>
</head>
<body class="bg-dark text-white pb-5">

    <div class="search-container">
        <input type="text" id="searchInput" placeholder="Digite para pesquisar..." 
               value="<?= htmlspecialchars($nomePesquisa) ?>" autocomplete="off">
        <label for="nicho" class="required"><i class="fas fa-running"></i> ||  Modalidade Esportiva</label>
  <select name="nicho" id="nicho" class="form-select w-auto d-inline">
    <option value="">Todos</option>
    <option value="Futebol" <?= isset($_GET['nicho']) && $_GET['nicho'] === 'Futebol' ? 'selected' : '' ?>>Futebol</option>
    <option value="Futsal" <?= isset($_GET['nicho']) && $_GET['nicho'] === 'Futsal' ? 'selected' : '' ?>>Futsal</option>
    <option value="Basquete" <?= isset($_GET['nicho']) && $_GET['nicho'] === 'Basquete' ? 'selected' : '' ?>>Basquete</option>
  </select>
        <div id="error"></div>
    </div>
    
    <div id="results">
        <?php if (!empty($campeonatos)): ?>
        <div class="table-responsive">
            <table>
                <tr>
                <th>Nome do campeonato</th>
                <th>Nome do dono</th>
                <th>Modalidade</th>
                <th>Endereço</th>
                </tr>
                <?php foreach ($campeonatos as $campeonato): ?>
                <tr>
                    <td><?= htmlspecialchars($campeonato->nome) ?></td>
                    <td><?= htmlspecialchars($campeonato->nome_dono) ?></td>
                    <td><?= htmlspecialchars($campeonato->nicho) ?></td>
                    <td><?= htmlspecialchars($campeonato->logradouro) ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <?php else: ?>
    <p><?= $nomePesquisa ? 'Nenhum campeonato encontrado.' : 'Nenhum campeonato cadastrado.' ?></p>
<?php endif; ?>
    </div>

<script>

                document.getElementById('nicho').addEventListener('change', function() {
                    document.getElementById('filtro-nicho').submit();
                });

                document.addEventListener('DOMContentLoaded', function() {
                    const searchInput = document.getElementById('searchInput');
                    const resultsDiv = document.getElementById('results');
                    const errorDiv = document.getElementById('error');
                    
                    searchInput.addEventListener('input', function() {
                        const searchTerm = this.value.trim();
                        
                        fetch(`../router.php?rota=buscar_ajax&nome=${encodeURIComponent(searchTerm)}`)
                    .then(response => {
                        if (!response.ok) throw new Error('Erro na rede');
                        return response.text(); // Agora esperamos HTML puro
                    })
                    .then(html => {
                        resultsDiv.innerHTML = html;
                        errorDiv.style.display = 'none';
                    })
                    .catch(error => {
                        errorDiv.textContent = 'Erro ao buscar campeonato: ' + error.message;
                        errorDiv.style.display = 'block';
                        console.error('Erro:', error);
                    });
                    });
                });
</script>

    <!-- ----------------------------------------------------------------------------------------------------------- -->

    <div class="barra">
        <nav class="bottom-nav d-flex justify-content-around py-2">
            <a href="../painel.php" class="nav-link text-center">
                <div>
                  <img src="../Imagens/home.png">
                </div>
                <small>Home</small>
            </a>
            <a href="search.php" class="nav-link text-center">
                <div>
                    <img src="../Imagens/lupa.png" >
                </div>
                <small>Pesquisar</small>
            </a>
            <a href="config.php" class="nav-link text-center">
                <div>
                  <img src="../Imagens/configuraçoes.png">
                </div>
                <small>Ajustes</small>
            </a>
        </nav>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
