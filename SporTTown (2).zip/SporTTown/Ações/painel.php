<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include('../models/Model.php');
$model = new Model();
$pdo = $model->getConnect();
$camps = $model->getAllCamps();

require_once('../configs/protected.php');

$nome = $_SESSION['usuario_nome'] ?? $_SESSION['empresa_nome'] ?? 'Nome não disponível';
$email = $_SESSION['usuario_email'] ?? $_SESSION['empresa_email'] ?? 'E-mail não disponível';
$cnpj = $_SESSION['empresa_cnpj'] ?? 'CNPJ não disponível';

$sql = "SELECT nome, nome_dono, email, nicho, cep, logradouro, bairro, cidade, estado, cnpj, target_file  FROM camps LIMIT 1"; // ou WHERE nicho = 'Tênis de Mesa' se quiser filtrar
$result = $pdo->query($sql);
$camp = $result->fetch(PDO::FETCH_ASSOC);



?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sport Town</title>
    <link rel="icon" type="image/png" href="../Imagens/favicon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body class="bg-dark text-white pb-5">
    <div class="profile-section">
        <div class="profile-text">
         <strong><?= htmlspecialchars($nome) ?></strong><br>
           <small><?= htmlspecialchars($email) ?></small><br>
                
         <?php if (isset($_SESSION['empresa_cnpj'])): ?>
                    <small>CNPJ: <?= htmlspecialchars($cnpj) ?></small><br>
         <?php endif; ?>
    
    <a href="../login/logout.php" class="sair"> <small>Sair</small> </a>
</div>
    </div>
    <!-- ----------------------------------------------------------------------------------------------------------- -->
    <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="../Imagens/1.png" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="../Imagens/2.png" class="d-block w-100" alt="...">
            </div>
            <div class="carousel-item">
                <img src="../Imagens/Zenir.jpg" class="d-block w-100" alt="...">
            </div>
        </div>
    </div>
    <!-- ----------------------------------------------------------------------------------------------------------- -->
    <br>
    <?php if (empty($camps)): ?>
    <p>Nenhum campeonato cadastrado.</p>
<?php else: ?>
    <?php foreach ($camps as $camp): ?>
    <?php
        // monta o caminho da imagem (inalterado)
        $relativePath = $camp['target_file'];
        $physicalPath = __DIR__ . '/../' . $relativePath;
        $webPath      = '../' . $relativePath;

        // 1) gera o nome do arquivo a partir do nome do campeonato
        $nomeArquivo = preg_replace('/[^a-zA-Z0-9_-]/', '_', $camp['nome']);
        // 2) monta o link para a página em Corpo/NomeSanitizado.php
        $link = "../Corpos/{$nomeArquivo}.php";
    ?>
    <!-- 3) envolve tudo com um <a> -->
    <a href="<?= $link ?>" 
       style="text-decoration: none; color: inherit; display: block;">
        <div class="container text-center my-4">
            <div class="row align-items-center border p-3 rounded">
                <!-- Coluna 1 -->
                <div class="col">
                    <h5><?= htmlspecialchars($camp['nome_dono']) ?></h5>
                    <p><?= htmlspecialchars($camp['email']) ?></p>
                    <p><?= htmlspecialchars($camp['cnpj']) ?></p>
                </div>

                <!-- Coluna 2 -->
                <div class="col">
                    <h5><?= htmlspecialchars($camp['nome']) ?></h5>
                    <p>
                        Nicho: <?= htmlspecialchars($camp['nicho']) ?><br>
                        Endereço: <?= htmlspecialchars($camp['logradouro']) ?>, <?= htmlspecialchars($camp['bairro']) ?><br>
                        Cidade: <?= htmlspecialchars($camp['cidade']) ?>/<?= htmlspecialchars($camp['estado']) ?>
                    </p>
                    <small>
                        Cadastrado em: <?= date('d/m/Y H:i', strtotime($camp['criado_em'])) ?>
                    </small>
                </div>

                <!-- Coluna 3 (imagem) -->
                <div class="col">
                    <?php if ($relativePath && file_exists($physicalPath)): ?>
                        <img src="<?= htmlspecialchars($webPath) ?>" width="100" alt="Imagem do campeonato">
                    <?php else: ?>
                        Sem imagem
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </a>
<?php endforeach; ?>

<?php endif; ?>


<div class="barra">
    <nav class="bottom-nav d-flex justify-content-around py-2">
        <a href="#" class="nav-link text-center">
            <div>
              <img src="../Imagens/home.png">
            </div>
            <small>Home</small>
        </a>
        <a href="search.php" class="nav-link text-center">
            <div>
                <img src="../Imagens/lupa.png" >
            </div>
            <small>Pesquisar</small>
        </a>
        <a href="config.php" class="nav-link text-center">
            <div>
              <img src="../Imagens/configuraçoes.png">
            </div>
            <small>Ajustes</small>
        </a>
    </nav>
</div>
<br>
<br>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
