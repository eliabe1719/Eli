<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include('../models/Model.php');
$model = new Model();
$pdo = $model->getConnect();

require_once('../configs/protected.php');

$nome = $_SESSION['usuario_nome'] ?? $_SESSION['empresa_nome'] ?? 'Nome não disponível';
$email = $_SESSION['usuario_email'] ?? $_SESSION['empresa_email'] ?? 'E-mail não disponível';
$cnpj = $_SESSION['empresa_cnpj'] ?? 'CNPJ não disponível';

$sql = "SELECT nome, nome_dono, email, nicho, logradouro, bairro, cidade, estado FROM camps LIMIT 1";
$result = $pdo->query($sql);
$camp = $result->fetch(PDO::FETCH_ASSOC);



?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../Imagens/favicon.png">
    <title>Sport Town</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #1a1a1a;
            color: #ffffff;
            line-height: 1.6;
            padding-bottom: 70px;
        }

        .profile-section {
            background: linear-gradient(135deg, #1a1a1a, #2d2d2d);
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 17, 17, 0.3);
            margin-bottom: 20px;
        }

        .profile-text strong {
            font-size: 20px;
            color: #fff;
            display: block;
            margin-bottom: 5px;
        }

        .profile-text small {
            color: #fff;
            font-size: 14px;
            display: block;
            margin-bottom: 3px;
        }

        .sair {
            color: #fff;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.3s ease;
            display: inline-block;
            margin-top: 10px;
        }

        .sair:hover {
            color: #fff;
            text-decoration: underline;
        }

        .btn-config {
            background: #23243a;
            border: 1.5px solid rgba(255, 17, 17, 0.13);
            border-radius: 14px;
            padding: 18px 18px 12px 18px;
            margin-bottom: 18px;
            transition: none;
            text-align: left;
        }

        .btn-config:hover {
            background: #23243a;
            border-color: #ff1111;
            transform: none;
            box-shadow: none;
        }

        .btn-config h5 {
            color: #ff1111;
            font-size: 1.1rem;
            font-weight: 700;
            margin: 0 0 2px 0;
            letter-spacing: 0.5px;
        }

        .btn-config small {
            color: #e0e0e0;
            font-size: 0.95rem;
            opacity: 0.95;
        }

        .status-badge {
            background: #ff1111;
            color: #fff !important;
            font-size: 0.95rem;
            padding: 6px 16px;
            border-radius: 20px;
            font-weight: 600;
            box-shadow: none;
            border: none;
        }

        .bottom-nav {
            background: #1a1a1a;
            z-index: 1000;
            border-top: 1.5px solid rgba(255, 17, 17, 0.18);
            position: fixed;
            bottom: 0;
            width: 100%;
            box-shadow: none;
            backdrop-filter: none;
        }

        .nav-link {
            text-decoration: none;
            color: #fff;
            transition: all 0.3s ease;
            padding: 8px 0;
        }

        .nav-link:hover {
            color: #fff;
        }

        .nav-link img {
            width: 32px;
            height: 32px;
            margin-bottom: 4px;
            transition: none;
            filter: none;
        }

        .nav-link:hover img {
            transform: none;
            filter: none;
        }

        .nav-link small {
            font-size: 13px;
            color: #fff;
            margin-top: 4px;
            display: block;
            font-weight: 500;
        }

        @media (max-width: 700px) {
            .profile-section {
                padding: 18px 0 12px 0;
            }
            .btn-config {
                padding: 12px 8px 8px 8px;
                border-radius: 10px;
            }
            .btn-config h5 {
                font-size: 1rem;
            }
            .nav-link img {
                width: 24px;
                height: 24px;
            }
        }
    </style>
</head>
<body class="bg-dark text-white pb-5">

<!-- Perfil do Usuário -->
<header class="profile-section py-3" style="background: linear-gradient(135deg, #1c1c1c, #2c3e50); border-bottom: 1px solid rgb(255, 40, 40); box-shadow: 0 4px 24px rgba(0,0,0,0.18);">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <!-- Logo/Ícone à Esquerda -->
            <div class="col-auto">
                <img src="../Imagens/favicon.png" alt="Logo" class="rounded-circle" style="width: 64px; height: 64px; box-shadow: 0 2px 12px rgba(255,40,40,0.12); border: 3px solid #fff2;">
            </div>
            <!-- Informações Centralizadas -->
            <div class="col text-center">
                <strong class="d-block" style="font-size: 1.5rem; color: #ff1111; font-weight: 700; letter-spacing: 1px; margin-bottom: 2px;"><?= htmlspecialchars($nome) ?></strong>
                <small class="d-block mb-1">
                    <a href="mailto:<?= htmlspecialchars($email) ?>" class="text-decoration-none" style="color:#e0e0e0; opacity:0.95;">
                        <?= htmlspecialchars($email) ?>
                    </a>
                </small>
                <?php if (isset($_SESSION['empresa_cnpj'])): ?>
                    <small class="d-block mb-1">
                        <a href="#" class="text-decoration-none" style="color:#e0e0e0; opacity:0.95;">
                            CNPJ: <?= htmlspecialchars($cnpj) ?>
                        </a>
                    </small>
                <?php endif; ?>
            </div>
            <!-- Botão "Sair" à Direita -->
            <div class="col-auto">
                <a href="../login/logout.php" class="btn btn-sm btn-outline-danger" style="font-size: 15px; padding: 7px 18px; border: 1.5px solid #ff1111; color: #ff1111; background: transparent; border-radius: 8px; font-weight: 600; box-shadow: 0 2px 8px rgba(255,17,17,0.08);"><i class="fas fa-sign-out-alt" style="margin-right:6px;"></i> Sair</a>
            </div>
        </div>
    </div>
</header>

    <!------------------------------------------------------------------------------------------------------------- -->
<br>
         <?php if (isset($_SESSION['tipo']) && $_SESSION['tipo'] === 'empresa'): ?>
    <button onclick="window.location.href='../cadastros/camps.php'" class="btn btn-light w-100 btn-config">
        <div>
            <h5 class="mb-1">Cadastrar Campeonatos</h5>
            <small class="text-muted" style="color: #fff !important;">TORNEIOS</small>
        </div>
    </button>
<?php endif; ?>

        <div class="position-relative">
            <button class="btn btn-light w-100 btn-config">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-1">Notificações</h5>
                        <small class="text-muted" style="color: #fff !important;">Receba alertas importantes</small>
                    </div>
                    <span class="badge bg-success status-badge" style="color: #fff !important;">ATIVADO</span>
                </div>
            </button>
        </div>

        <button class="btn btn-light w-100 btn-config">
            <div>
                <h5 class="mb-1">Cadastrar Anúncios</h5>
                <small class="text-muted" style="color: #fff !important;">ANÚNCIOS</small>
            </div>
        </button>
        
        <button class="btn btn-light w-100 btn-config">
            <div>
                <h5 class="mb-1">RIA 13 DE MAIO, IGUALDADE</h5>
                <small class="text-muted" style="color: #fff !important;">ENDEREÇO</small>
            </div>
        </button>
        <button class="btn btn-light w-100 btn-config">
            <div>
                <h5 class="mb-1">Segurança e Privacidade</h5>
                <small class="text-muted" style="color: #fff !important;">SEGURANÇA E PRIVACIDADE</small>
            </div>
        </button>

        <button class="btn btn-light w-100 btn-config">
            <div>
                <h5 class="mb-1">Suporte</h5>
                <small class="text-muted" style="color: #fff !important;">CONTATO</small>
            </div>
        </button>
    </div>
    <!-- ----------------------------------------------------------------------------------------------------------- -->
   
<div class="barra">
    <nav class="bottom-nav d-flex justify-content-around py-2">
        <a href="../painel.php" class="nav-link text-center">
            <div>
              <img src="../Imagens/home.png">
            </div>
            <small>Home</small>
        </a>
        <a href="search.php" class="nav-link text-center">
            <div>
                <img src="../Imagens/lupa.png" >
            </div>
            <small>Pesquisar</small>
        </a>
        <a href="#" class="nav-link text-center">
            <div>
              <img src="../Imagens/configuraçoes.png">
            </div>
            <small>Ajustes</small>
        </a>
    </nav>
</div>
<br>
<br>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
