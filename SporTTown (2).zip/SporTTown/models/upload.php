<?php
function fazerUpload(array $arquivo): string {
    $diretorioUploads = "imgs/";
    if (!file_exists($diretorioUploads)) {
        mkdir($diretorioUploads, 0755, true);
    }

    if ($arquivo['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException("Erro no upload: " . $arquivo['error']);
    }

    $extensao = strtolower(pathinfo($arquivo['name'], PATHINFO_EXTENSION));
    $permitidas = ['jpg','jpeg','png'];
    if (!in_array($extensao, $permitidas)) {
        throw new RuntimeException("Tipo de arquivo não permitido.");
    }

    $novoNome = uniqid('img_') . '.' . $extensao;
    $caminhoSeguro = $diretorioUploads . $novoNome;

    if (!move_uploaded_file($arquivo['tmp_name'], $caminhoSeguro)) {
        throw new RuntimeException("Falha ao mover o arquivo.");
    }

    return $caminhoSeguro;
}
