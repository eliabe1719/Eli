<?php
require_once('../models/Model.php');
require_once '../controllers/Controller.php';
$controller = new Controller();
$campeonatos = $controller->listar();
$nomePesquisa = $_GET['nome'] ?? '';
$campeonatos = $nomePesquisa ? $controller->buscarPorNome($nomePesquisa) : $controller->listar();
$nichoSelecionado = $_GET['nicho'] ?? '';
$model = new Model();
$pdo = $model->getConnect();

if (!empty($nichoSelecionado)) {
    $stmt = $pdo->prepare("SELECT * FROM camps WHERE nicho = :nicho");
    $stmt->bindParam(':nicho', $nichoSelecionado);
} else {
    $stmt = $pdo->prepare("SELECT * FROM camps");
}

$stmt->execute();
$camps = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../Imagens/favicon.png">
    <title>Sport Town</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #1a1a1a;
            color: #ffffff;
            line-height: 1.6;
            padding-bottom: 70px;
        }

        .search-container {
            background: linear-gradient(135deg, #1a1a1a, #2d2d2d);
            padding: 20px;
            border-bottom: 1px solid rgba(255, 17, 17, 0.3);
            margin-bottom: 20px;
        }

        #searchInput {
            width: 100%;
            padding: 12px;
            border: 1px solid rgba(255, 17, 17, 0.2);
            border-radius: 6px;
            background-color: #2d2d2d;
            color: #ffffff;
            margin-bottom: 15px;
            transition: all 0.3s ease;
        }

        #searchInput:focus {
            outline: none;
            border-color: rgb(255, 17, 17);
            box-shadow: 0 0 0 2px rgba(255, 17, 17, 0.2);
        }

        #searchInput::placeholder {
            color: #b0b0b0;
        }

        label {
            color: #e0e0e0;
            margin-bottom: 8px;
            display: block;
        }

        .form-select {
            background-color: #2d2d2d;
            color: #ffffff;
            border: 1px solid rgba(255, 17, 17, 0.2);
            border-radius: 6px;
            padding: 8px 12px;
            transition: all 0.3s ease;
        }

        .form-select:focus {
            border-color: rgb(255, 17, 17);
            box-shadow: 0 0 0 2px rgba(255, 17, 17, 0.2);
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin: 20px 0;
            background-color: #2d2d2d;
            border-radius: 8px;
            overflow: hidden;
        }

        th {
            background-color: #1a1a1a;
            color: rgb(255, 17, 17);
            padding: 12px;
            text-align: left;
            font-weight: 600;
            border-bottom: 2px solid rgba(255, 17, 17, 0.3);
        }

        td {
            padding: 12px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            color: #e0e0e0;
        }

        tr:hover {
            background-color: #363636;
        }

        #error {
            color: rgb(255, 17, 17);
            margin-top: 10px;
            font-size: 14px;
        }

        .bottom-nav {
            background-color: #1a1a1a;
            border-top: 1px solid rgba(255, 17, 17, 0.3);
            box-shadow: 0 -4px 10px rgba(0, 0, 0, 0.2);
            display: flex;
            justify-content: space-around;
            align-items: center;
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            z-index: 999;
            width: auto;
            max-width: none;
            height: auto;
            min-height: 0;
            margin: 0;
            padding: 0.5rem 0;
            overflow-x: auto;
        }

        .nav-link {
            text-decoration: none;
            color: #e0e0e0;
            transition: all 0.3s ease;
        }

        .nav-link:hover {
            color: rgb(255, 17, 17);
        }

        .nav-link img {
            width: 24px;
            height: 24px;
            margin-bottom: 4px;
            transition: transform 0.3s ease;
        }

        .nav-link:hover img {
            transform: scale(1.1);
        }

        .nav-link small {
            font-size: 12px;
            display: block;
            margin-top: 4px;
        }

        @media (max-width: 768px) {
            .search-container {
                padding: 15px;
            }

            #searchInput {
                padding: 10px;
            }

            th, td {
                padding: 10px;
                font-size: 14px;
            }
            .form-select {
                width: 100% !important;
                min-width: 0;
            }
        }
        @media (max-width: 600px) {
            .search-container {
                padding: 10px;
            }
            #searchInput {
                font-size: 1rem;
            }
            .form-select {
                font-size: 1rem;
            }
            .bottom-nav {
                font-size: 0.95rem;
                padding: 0.3rem 0;
                width: auto;
                max-width: none;
            }
            .nav-link img {
                width: 20px;
                height: 20px;
            }
        }
        .table-responsive {
            width: 100%;
            overflow-x: auto;
        }
    </style>
</head>
<body class="bg-dark text-white pb-5">

    <div class="search-container">
        <input type="text" id="searchInput" placeholder="Digite para pesquisar..." 
               value="<?= htmlspecialchars($nomePesquisa) ?>" autocomplete="off">
        <label for="nicho" class="required"><i class="fas fa-running"></i> ||  Modalidade Esportiva</label>
  <select name="nicho" id="nicho" class="form-select w-auto d-inline">
    <option value="">Todos</option>
    <option value="Futebol" <?= isset($_GET['nicho']) && $_GET['nicho'] === 'Futebol' ? 'selected' : '' ?>>Futebol</option>
    <option value="Futsal" <?= isset($_GET['nicho']) && $_GET['nicho'] === 'Futsal' ? 'selected' : '' ?>>Futsal</option>
    <option value="Basquete" <?= isset($_GET['nicho']) && $_GET['nicho'] === 'Basquete' ? 'selected' : '' ?>>Basquete</option>
  </select>
        <div id="error"></div>
    </div>
    
    <div id="results">
        <?php if (!empty($campeonatos)): ?>
        <div class="table-responsive">
            <table>
                <tr>
                <th>Nome do campeonato</th>
                <th>Nome do dono</th>
                <th>Modalidade</th>
                <th>Endereço</th>
                </tr>
                <?php foreach ($campeonatos as $campeonato): ?>
                <tr>
                    <td><?= htmlspecialchars($campeonato->nome) ?></td>
                    <td><?= htmlspecialchars($campeonato->nome_dono) ?></td>
                    <td><?= htmlspecialchars($campeonato->nicho) ?></td>
                    <td><?= htmlspecialchars($campeonato->logradouro) ?></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <?php else: ?>
    <p><?= $nomePesquisa ? 'Nenhum campeonato encontrado.' : 'Nenhum campeonato cadastrado.' ?></p>
<?php endif; ?>
    </div>

<script>

                document.getElementById('nicho').addEventListener('change', function() {
                    document.getElementById('filtro-nicho').submit();
                });

                document.addEventListener('DOMContentLoaded', function() {
                    const searchInput = document.getElementById('searchInput');
                    const resultsDiv = document.getElementById('results');
                    const errorDiv = document.getElementById('error');
                    
                    searchInput.addEventListener('input', function() {
                        const searchTerm = this.value.trim();
                        
                        fetch(`../router.php?rota=buscar_ajax&nome=${encodeURIComponent(searchTerm)}`)
                    .then(response => {
                        if (!response.ok) throw new Error('Erro na rede');
                        return response.text(); // Agora esperamos HTML puro
                    })
                    .then(html => {
                        resultsDiv.innerHTML = html;
                        errorDiv.style.display = 'none';
                    })
                    .catch(error => {
                        errorDiv.textContent = 'Erro ao buscar campeonato: ' + error.message;
                        errorDiv.style.display = 'block';
                        console.error('Erro:', error);
                    });
                    });
                });
</script>

    <!-- ----------------------------------------------------------------------------------------------------------- -->

    <div class="barra">
        <nav class="bottom-nav d-flex justify-content-around py-2" style="position:fixed;bottom:0;left:0;right:0;z-index:999;">
            <a href="../painel.php" class="nav-link text-center">
                <div>
                  <img src="../Imagens/home.png">
                </div>
                <small>Home</small>
            </a>
            <a href="search.php" class="nav-link text-center">
                <div>
                    <img src="../Imagens/lupa.png" >
                </div>
                <small>Pesquisar</small>
            </a>
            <a href="config.php" class="nav-link text-center">
                <div>
                  <img src="../Imagens/configuraçoes.png">
                </div>
                <small>Ajustes</small>
            </a>
        </nav>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
