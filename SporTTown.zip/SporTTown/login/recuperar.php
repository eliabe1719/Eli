<?php

session_start(); // Iniciar a sessão

ob_start(); // Limpar o buffer de saída

// Importar as classes
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Incluir o arquivo config
include_once "../configs/config.php";

// Incluir o arquivo com a conexão com banco de dados
include_once "../models/Model.php";
$model = new Model();
$conn = $model->getConnect();

// Verificar se a coluna chave_recuperar_senha existe, se não, criar
try {
    $checkColumn = $conn->query("SHOW COLUMNS FROM usuario LIKE 'chave_recuperar_senha'");
    if ($checkColumn->rowCount() == 0) {
        $conn->exec("ALTER TABLE usuario ADD COLUMN chave_recuperar_senha VARCHAR(255) NULL");
    }
} catch (PDOException $e) {
    // Se der erro, continua sem a coluna
    error_log("Erro ao verificar/criar coluna chave_recuperar_senha: " . $e->getMessage());
}

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/png" href="../Imagens/favicon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Senha</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #1a1a1a;
            color: #ffffff;
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        h1 {
            color: rgb(255, 17, 17);
            margin-bottom: 24px;
            font-size: 2rem;
        }
        form {
            background: linear-gradient(135deg, #1a1a1a, #2d2d2d);
            padding: 32px 24px;
            border-radius: 10px;
            box-shadow: 0 4px 16px rgba(0,0,0,0.25);
            min-width: 320px;
            max-width: 90vw;
            margin-bottom: 24px;
        }
        label {
            color: #e0e0e0;
            font-size: 15px;
            margin-bottom: 8px;
            display: block;
        }
        input[type="text"] {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid rgba(255, 17, 17, 0.2);
            border-radius: 6px;
            background-color: #2d2d2d;
            color: #fff;
            margin-bottom: 18px;
            transition: border 0.3s, box-shadow 0.3s;
        }
        input[type="text"]:focus {
            outline: none;
            border-color: rgb(255, 17, 17);
            box-shadow: 0 0 0 2px rgba(255, 17, 17, 0.15);
        }
        input[type="submit"] {
            background-color: rgb(255, 17, 17);
            color: #fff;
            border: none;
            border-radius: 6px;
            padding: 10px 24px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s;
        }
        input[type="submit"]:hover {
            background-color: #ff4d4d;
        }
        a {
            color: rgb(255, 17, 17);
            text-decoration: none;
            transition: color 0.3s;
        }
        a:hover {
            color: #ff4d4d;
            text-decoration: underline;
        }
        .msg {
            margin-bottom: 18px;
            font-size: 15px;
        }
        @media (max-width: 480px) {
            form {
                padding: 18px 8px;
                min-width: unset;
            }
            h1 {
                font-size: 1.3rem;
            }
        }
    </style>
</head>

<body>
    <h1>Recuperar Senha</h1>

    <?php
    // Receber os dados do formulário
    $dados = filter_input_array(INPUT_POST, FILTER_DEFAULT);

    // Validação do e-mail
    if (!empty($dados['SendRecupSenha'])) {
        $email = trim($dados['email'] ?? '');
        if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $_SESSION['msg'] = "<p style='color: #f00;'>Por favor, preencha um e-mail válido.</p>";
        } else {
            // QUERY para recuperar os dados do usuário no banco de dados
            $query_usuario = "SELECT id, nome, email 
                            FROM usuario
                            WHERE email =:email
                            LIMIT 1";

            // Preparar a QUERY
            $result_usuario = $conn->prepare($query_usuario);

            // Substituir o link da query pelo valor que vem do formulário
            $result_usuario->bindParam(':email', $email);

            // Executar a QUERY
            $result_usuario->execute();

            // Acessar o IF quando encontrar usuário no banco de dados
            if (($result_usuario) and ($result_usuario->rowCount() != 0)) {
                // Ler os registros retorando do banco de dados
                $row_usuario = $result_usuario->fetch(PDO::FETCH_ASSOC);
                //var_dump($row_usuario);

                // Gerar a chave para recuperar senha
                $chave_recuperar_senha = password_hash($row_usuario['id'] . $row_usuario['email'], PASSWORD_DEFAULT);
                //var_dump($chave_recuperar_senha);

                // Editar o usuário e salvar a chave recuperar senha
                $query_up_usuario = "UPDATE usuario 
                            SET chave_recuperar_senha =:chave_recuperar_senha
                            WHERE id =:id
                            LIMIT 1";

                // Preparar a QUERY
                $editar_usuario = $conn->prepare($query_up_usuario);

                // Substituir o link da query pelo valor que vem do formulário
                $editar_usuario->bindParam(':chave_recuperar_senha', $chave_recuperar_senha);
                $editar_usuario->bindParam(':id', $row_usuario['id']);

                // Executar a QUERY
                if ($editar_usuario->execute()) {
                    // Gerar o link recuperar senha
                    $link = "http://localhost/celke/atualizar_senha.php?chave=$chave_recuperar_senha";
                    //var_dump($link);

                    // Incluir manualmente os arquivos do PHPMailer instalados em libs/PHPMailer
                    require_once __DIR__ . '/../libs/PHPMailer/src/PHPMailer.php';
                    require_once __DIR__ . '/../libs/PHPMailer/src/SMTP.php';
                    require_once __DIR__ . '/../libs/PHPMailer/src/Exception.php';

                    // Criar o objeto e instanciar a classe do PHPMailer
                    $mail = new PHPMailer(true);

                    // Verificar se envia o e-mail corretamente com try catch
                    try {
                        // Imprimir os erro com debug
                        //$mail->SMTPDebug = SMTP::DEBUG_SERVER;

                        // Permitir o envio do e-mail com caracteres especiais
                        $mail->CharSet = 'UTF-8';

                        // Definir para usar SMTP
                        $mail->isSMTP();

                        // Servidor de envio de e-mail
                        $mail->Host       = HOSTEMAIL; 

                        // Indicar que é necessário autenticar
                        $mail->SMTPAuth   = true;     

                        // Usuário/e-mail para enviar o e-mail                              
                        $mail->Username   = USEREMAIL; 

                        // Senha do e-mail utilizado para enviar e-mail                  
                        $mail->Password   = PASSEMAIL;      

                        // Ativar criptografia                         
                        $mail->SMTPSecure = SMTPSECURE;  

                        // Porta para enviar e-mail          
                        $mail->Port       = PORTEMAIL;

                        // E-mail do rementente
                        $mail->setFrom(REMETENTE, NOMEREMETENTE);
                        
                        // E-mail de destino
                        $mail->addAddress($row_usuario['email'], $row_usuario['nome']);

                        // Definir formato de e-mail para HTML
                        $mail->isHTML(true);

                        // Título do e-mail
                        $mail->Subject = 'Recuperar senha';

                        // Conteúdo do e-mail em formato HTML
                        $mail->Body    = "Olá " . $row_usuario['nome'] . ".<br><br>Você solicitou alteração de senha.<br><br>Para continuar o processo de recuperação de sua senha, clique no link abaixo ou cole o endereço no seu navegador: <br><br><a href='" . $link . "'>" . $link . "</a><br><br>Se você não solicitou essa alteração, nenhuma ação é necessária. Sua senha permanecerá a mesma até que você ative este código.<br><br>";

                        // Conteúdo do e-mail em formato texto
                        $mail->AltBody = "Olá " . $row_usuario['nome'] . "\n\nVocê solicitou alteração de senha.\n\nPara continuar o processo de recuperação de sua senha, clique no link abaixo ou cole o endereço no seu navegador: \n\n" . $link . "\n\nSe você não solicitou essa alteração, nenhuma ação é necessária. Sua senha permanecerá a mesma até que você ative este código.\n\n";

                        // Enviar e-mail
                        $mail->send();

                        // Criar a variável global com a mensagem de sucesso
                        $_SESSION['msg'] = "<p style='color: green;'>Enviado e-mail com instruções para recuperar a senha. Acesse a sua caixa de e-mail para recuperar a senha!</p>";

                        // Redirecionar o usuário
                        header('Location: index.php');

                        // Pausar o processamento
                        exit();
                    } catch (Exception $e) { // Acessa o catch quando não é enviado e-mail corretamente
                        echo "E-mail não enviado com sucesso. Erro: {$mail->ErrorInfo}";
                        $_SESSION['msg'] = "<p style='color: #f00;'>Erro: E-mail não enviado com sucesso!</p>";
                    }
                } else {
                    $_SESSION['msg'] = "<p style='color: #f00;'>Erro: Tente novamente!</p>";
                }
            } else {
                $_SESSION['msg'] = "<p style='color: #f00;'>Erro: Usuário não encontrado!</p>";
            }
        }
    }

    // Imprimir a mensagem da sessão
    if (isset($_SESSION['msg'])) {
        echo $_SESSION['msg'];
        unset($_SESSION['msg']);
    }
    ?>

    <form method="POST" action="">
        <label>E-mail</label>
        <input type="text" name="email" placeholder="Digite seu e-mail"><br><br>

        <input type="submit" name="SendRecupSenha" value="Recuperar"><br><br>
    </form>

    Lembrou a senha? <a href="index.php">clique aqui</a> para logar
</body>

</html>