<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include('../models/Model.php');
$model = new Model();
$pdo = $model->getConnect();

$erro = false;

if (isset($_POST['email'], $_POST['senha'])) {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    // Primeiro tenta como usuario
    $stmt = $pdo->prepare("SELECT * FROM usuario WHERE email = ?");
    $stmt->execute([$email]);
    $usuario = $stmt->fetch(PDO::FETCH_OBJ);

    if ($usuario && password_verify($senha, $usuario->senha)) {
        // Limpa sessão anterior da empresa
        unset($_SESSION['empresa_id'], $_SESSION['empresa_nome'], $_SESSION['empresa_email']);

        $_SESSION['usuario_id'] = $usuario->id;
        $_SESSION['usuario_nome'] = $usuario->nome;
        $_SESSION['usuario_email'] = $usuario->email;
        $_SESSION['tipo'] = 'usuario';
        header("Location: ../painel.php");
        exit;
    }

    // Se não for usuário, tenta como empresa
    $stmt = $pdo->prepare("SELECT * FROM empresa WHERE email = ?");
    $stmt->execute([$email]);
    $empresa = $stmt->fetch(PDO::FETCH_OBJ);

    if ($empresa && password_verify($senha, $empresa->senha)) {
        // Limpa sessão anterior do usuário
        unset($_SESSION['usuario_id'], $_SESSION['usuario_nome'], $_SESSION['usuario_email']);

        $_SESSION['empresa_id'] = $empresa->id;
        $_SESSION['empresa_nome'] = $empresa->nome;
        $_SESSION['empresa_email'] = $empresa->email;
        $_SESSION['empresa_cnpj'] = $empresa->cnpj;
        $_SESSION['tipo'] = 'empresa';
        header("Location: ../painel.php");
        exit;
    }

    // Nenhum encontrado
    $erro = true;
}?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/png" href="../Imagens/favicon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <title> Login </title>
        <style>
        /* Reset básico */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-image: url('../Imagens/fundol.png');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            color: #fff;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .login-container {
            background-color: rgba(17, 17, 17, 0.95); /* Mais opaco para contraste */
            padding: 30px 20px;
            border-radius: 12px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 0 20px rgba(255, 0, 0, 0.6);
            text-align: center;
            animation: fadeInUp 0.8s ease-out;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .login-container h1 {
            font-size: 24px;
            margin-bottom: 10px;
            color: rgb(243, 18, 18);
        }

        .login-container h4 {
            font-weight: normal;
            color: #ccc;
            margin-bottom: 25px;
            font-size: 14px;
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        input[type="text"],
        input[type="password"] {
            padding: 12px 15px;
            border: none;
            border-radius: 8px;
            background-color: #222;
            color: #fff;
            font-size: 16px;
            transition: 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            outline: none;
            background-color: #333;
            box-shadow: 0 0 5px rgb(243, 18, 18);
        }

        button {
            padding: 12px;
            background-color: rgb(255, 0, 0);
            color: white;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: rgb(243, 18, 18);
        }

        a {
            display: block;
            margin-top: 12px;
            color: #fff;
            text-decoration: none;
            font-size: 14px;
            transition: color 0.3s ease;
        }

        a:hover {
            color: rgb(243, 18, 18);
        }

        p {
            margin-top: 15px;
            color: rgb(255, 0, 0);
            font-size: 14px;
        }

        /* Responsividade */
        @media (max-width: 500px) {

            body{
                background-image: url('../Imagens/fundo.png');
                background-size: cover;
                background-position: 0 50%;
                background-repeat: no-repeat;
            }

            .login-container {
                padding: 25px 15px;
                margin: 10px;
            }

            .login-container h1 {
                font-size: 22px;
            }

            input[type="text"],
            input[type="password"] {
                font-size: 15px;
            }

            button {
                font-size: 15px;
            }
        }
        </style>
</head>
<body>
    <div class="login-container">
        <h1>Login</h1>
        <h4>Conecte-se para continuar</h4>
        <form action="" method="POST">
            <input type="text" name="email" placeholder="Email:" required>
            <div style="position: relative;">
                <input type="password" id="senha" name="senha" placeholder="Confirme sua senha" required>
                <i class="fas fa-eye password-toggle" id="togglePassword" 
                   style="position: absolute; right: 10px; top: 12px; cursor: pointer;"></i>
            </div>
            
            <button type="submit">Entrar</button>
        </form>
        <a href="../cadastros/cadastrar.php">Fazer Cadastro</a>
        <a href="../cadastros/empresa.php">Cadastro como Empresa</a>
        <a href="recuperar.php">Esqueceu a senha?</a>
        <br>
        <?php if (!empty($erro)): ?>
            <p style="color: red; text-align:center;">Credenciais incorretas.</p>
            <?php endif; ?>
      </div>
      <script>
        document.addEventListener('DOMContentLoaded', function() {
            const togglePassword = document.getElementById('togglePassword');
            const passwordInput = document.getElementById('senha');
            
            if (togglePassword && passwordInput) {
                togglePassword.addEventListener('click', function() {
                    const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                    passwordInput.setAttribute('type', type);
                    
                    // Alternar entre os ícones
                    togglePassword.classList.toggle('fa-eye');
                    togglePassword.classList.toggle('fa-eye-slash');
                });
            }
        });
    </script>
</body>
</html>