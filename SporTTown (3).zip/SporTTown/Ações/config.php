<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include('../models/Model.php');
$model = new Model();
$pdo = $model->getConnect();

require_once('../configs/protected.php');

$nome = $_SESSION['usuario_nome'] ?? $_SESSION['empresa_nome'] ?? 'Nome não disponível';
$email = $_SESSION['usuario_email'] ?? $_SESSION['empresa_email'] ?? 'E-mail não disponível';
$cnpj = $_SESSION['empresa_cnpj'] ?? 'CNPJ não disponível';

$sql = "SELECT nome, nome_dono, email, nicho, logradouro, bairro, cidade, estado FROM camps LIMIT 1";
$result = $pdo->query($sql);
$camp = $result->fetch(PDO::FETCH_ASSOC);



?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../Imagens/favicon.png">
    <title>Sport Town</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(135deg, #181818 60%, #23243a 100%); color: #f5f5f5; line-height: 1.6; padding-bottom: 80px; min-height: 100vh; } .profile-section { background: linear-gradient(135deg, #23243a 60%, #181818 100%); padding: 32px 0 24px 0; text-align: center; border-bottom: 1px solid rgba(255, 40, 40, 0.15); box-shadow: 0 4px 24px rgba(0,0,0,0.18); } .profile-section img { width: 64px; height: 64px; object-fit: cover; border-radius: 50%; box-shadow: 0 2px 12px rgba(255,40,40,0.12); border: 3px solid #fff2; transition: transform 0.3s ease; } .profile-section img:hover { transform: scale(1.1); } .profile-section strong { font-size: 1.5rem; color: #ff1111; font-weight: 700; letter-spacing: 1px; display: block; margin-bottom: 2px; } .profile-section small, .profile-section a { font-size: 1rem; color: #e0e0e0 !important; opacity: 0.95; } .btn-outline-danger { font-size: 15px; padding: 7px 18px; border: 1.5px solid #ff1111; color: #ff1111; background: transparent; border-radius: 8px; font-weight: 600; transition: background 0.3s, color 0.3s; box-shadow: 0 2px 8px rgba(255,17,17,0.08); } .btn-outline-danger i { margin-right: 6px; } .btn-outline-danger:hover { background: #ff1111; color: #fff; } .btn-config { background: linear-gradient(135deg, #23243a 60%, #181818 100%); border: 1.5px solid rgba(255, 40, 40, 0.13); border-radius: 14px; padding: 18px 18px 12px 18px; margin-bottom: 18px; transition: none; text-align: left; } .btn-config h5 { color: #ff1111; font-size: 1.1rem; font-weight: 700; margin: 0 0 2px 0; letter-spacing: 0.5px; } .btn-config small { color: #e0e0e0; font-size: 0.95rem; opacity: 0.95; } .status-badge { background: #ff1111; color: #fff !important; font-size: 0.95rem; padding: 6px 16px; border-radius: 20px; font-weight: 600; box-shadow: none; border: none; } .bottom-nav { box-shadow: 0 -4px 24px rgba(0,0,0,0.18); background: rgba(26,26,26,0.98); z-index: 1000; border-top: 1.5px solid rgba(255, 40, 40, 0.18); backdrop-filter: blur(2px); position: fixed; bottom: 0; left: 0; width: 100%; } .nav-icon { width: 34px; height: 34px; transition: transform 0.3s, filter 0.3s; filter: grayscale(100%); } .nav-icon:hover { transform: scale(1.13); filter: grayscale(0%); } .nav-link small { font-size: 13px; color: #fff; margin-top: 4px; display: block; transition: color 0.3s; font-weight: 500; } .nav-link:hover small { color: #ff1111; } .nav-link { text-decoration: none; color: inherit; } @media (max-width: 700px) { body { padding-bottom: 100px; } .profile-section { padding: 18px 0 12px 0; } .profile-section img { width: 44px; height: 44px; } .btn-config { padding: 12px 8px 8px 8px; border-radius: 10px; } .btn-config h5 { font-size: 1rem; } }
    </style>
</head>
<body class="bg-dark text-white pb-5">

<!-- Perfil do Usuário -->
<header class="profile-section py-3" style="background: linear-gradient(135deg, #1c1c1c, #2c3e50); border-bottom: 1px solid rgb(255, 40, 40); box-shadow: 0 4px 24px rgba(0,0,0,0.18);">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <!-- Logo/Ícone à Esquerda -->
            <div class="col-auto">
                <img src="../Imagens/favicon.png" alt="Logo" class="rounded-circle" style="width: 64px; height: 64px; box-shadow: 0 2px 12px rgba(255,40,40,0.12); border: 3px solid #fff2;">
            </div>
            <!-- Informações Centralizadas -->
            <div class="col text-center">
                <strong class="d-block" style="font-size: 1.5rem; color: #ff1111; font-weight: 700; letter-spacing: 1px; margin-bottom: 2px;"><?= htmlspecialchars($nome) ?></strong>
                <small class="d-block mb-1">
                    <a href="mailto:<?= htmlspecialchars($email) ?>" class="text-decoration-none" style="color:#e0e0e0; opacity:0.95;">
                        <?= htmlspecialchars($email) ?>
                    </a>
                </small>
                <?php if (isset($_SESSION['empresa_cnpj'])): ?>
                    <small class="d-block mb-1">
                        <a href="#" class="text-decoration-none" style="color:#e0e0e0; opacity:0.95;">
                            CNPJ: <?= htmlspecialchars($cnpj) ?>
                        </a>
                    </small>
                <?php endif; ?>
            </div>
            <!-- Botão "Sair" à Direita -->
            <div class="col-auto">
                <a href="../login/logout.php" class="btn btn-sm btn-outline-danger" style="font-size: 15px; padding: 7px 18px; border: 1.5px solid #ff1111; color: #ff1111; background: transparent; border-radius: 8px; font-weight: 600; box-shadow: 0 2px 8px rgba(255,17,17,0.08);"><i class="fas fa-sign-out-alt" style="margin-right:6px;"></i> Sair</a>
            </div>
        </div>
    </div>
</header>

    <!------------------------------------------------------------------------------------------------------------- -->
<br>
         <?php if (isset($_SESSION['tipo']) && $_SESSION['tipo'] === 'empresa'): ?>
    <button onclick="window.location.href='../cadastros/camps.php'" class="btn btn-light w-100 btn-config">
        <div>
            <h5 class="mb-1">Cadastrar Campeonatos</h5>
            <small class="text-muted" style="color: #fff !important;">TORNEIOS</small>
        </div>
    </button>
<?php endif; ?>

        <div class="position-relative">
            <button class="btn btn-light w-100 btn-config">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-1">Notificações</h5>
                        <small class="text-muted" style="color: #fff !important;">Receba alertas importantes</small>
                    </div>
                    <span class="badge bg-success status-badge" style="color: #fff !important;">ATIVADO</span>
                </div>
            </button>
        </div>

        <button class="btn btn-light w-100 btn-config">
            <div>
                <h5 class="mb-1">Cadastrar Anúncios</h5>
                <small class="text-muted" style="color: #fff !important;">ANÚNCIOS</small>
            </div>
        </button>
         <?php if (isset($_SESSION['tipo']) && $_SESSION['tipo'] === 'empresa'): ?>
    <button onclick="window.location.href='../Ações/saveCamp.php'" class="btn btn-light w-100 btn-config">
        <div>
            <h5 class="mb-1">Meus Campeonatos</h5>
            <small class="text-muted" style="color: #fff !important;">TORNEIOS</small>
        </div>
    </button>
<?php endif; ?>
        <button class="btn btn-light w-100 btn-config">
            <div>
                <h5 class="mb-1">RUA 13 DE MAIO, IGUALDADE</h5>
                <small class="text-muted" style="color: #fff !important;">ENDEREÇO</small>
            </div>
        </button>
        <button class="btn btn-light w-100 btn-config">
            <div>
                <h5 class="mb-1">Segurança e Privacidade</h5>
                <small class="text-muted" style="color: #fff !important;">SEGURANÇA E PRIVACIDADE</small>
            </div>
        </button>

        <button class="btn btn-light w-100 btn-config">
            <div>
                <h5 class="mb-1">Suporte</h5>
                <small class="text-muted" style="color: #fff !important;">CONTATO</small>
            </div>
        </button>
    </div>
    <!-- ----------------------------------------------------------------------------------------------------------- -->
   
<div class="barra">
    <nav class="bottom-nav d-flex justify-content-around py-2">
        <a href="../painel.php" class="nav-link text-center">
            <div>
              <img src="../Imagens/home.png">
            </div>
            <small>Home</small>
        </a>
        <a href="search.php" class="nav-link text-center">
            <div>
                <img src="../Imagens/lupa.png" >
            </div>
            <small>Pesquisar</small>
        </a>
        <a href="#" class="nav-link text-center">
            <div>
              <img src="../Imagens/configuraçoes.png">
            </div>
            <small>Ajustes</small>
        </a>
    </nav>
</div>
<br>
<br>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
