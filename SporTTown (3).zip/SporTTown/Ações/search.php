<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/SporTTown/models/Model.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/SporTTown/controllers/Controller.php';
require_once $_SERVER['DOCUMENT_ROOT'] . '/SporTTown/configs/protected.php';

function getModalidadeBadge($nicho) {
    $icons = [
        'Futebol' => '<img src="../Imagens/futebol.png" alt="Futebol" style="width:22px;vertical-align:middle;">',
        'Futsal' => '<img src="../Imagens/futsal.png" alt="Futsal" style="width:22px;vertical-align:middle;">',
        'Vôlei' => '<img src="../Imagens/vôlei.png" alt="Vôlei" style="width:22px;vertical-align:middle;">',
        'Basquete' => '<img src="../Imagens/basquete.png" alt="Basquete" style="width:22px;vertical-align:middle;">',
        'Tênis de mesa' => '<img src="../Imagens/tenis de mesa.png" alt="Tênis de mesa" style="width:22px;vertical-align:middle;">',
        'Xadrez' => '<img src="../Imagens/icons8-configuração-50 (1).png" alt="Xadrez" style="width:22px;vertical-align:middle;">',
    ];
    $classes = [
        'Futebol' => 'badge-modalidade badge-futebol',
        'Futsal' => 'badge-modalidade badge-futsal',
        'Vôlei' => 'badge-modalidade badge-volei',
        'Basquete' => 'badge-modalidade badge-basquete',
        'Tênis de mesa' => 'badge-modalidade badge-tenis',
        'Xadrez' => 'badge-modalidade badge-xadrez',
    ];
    $icon = $icons[$nicho] ?? '';
    $class = $classes[$nicho] ?? 'badge-modalidade';
    return '<span class="' . $class . '">' . $icon . htmlspecialchars($nicho) . '</span>';
}

$controller = new Controller();
$nomePesquisa = $_GET['nome'] ?? '';
$nichoSelecionado = $_GET['nicho'] ?? '';

// Usar a função correta para busca
$campeonatos = $controller->buscarCampeonatosPorFiltros($nomePesquisa, $nichoSelecionado);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../Imagens/favicon.png">
    <title>Sport Town</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style> body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(135deg, #181818 60%, #23243a 100%); color: #f5f5f5; line-height: 1.6; padding-bottom: 80px; min-height: 100vh; } .profile-section { background: linear-gradient(135deg, #23243a 60%, #181818 100%); padding: 32px 0 24px 0; text-align: center; border-bottom: 1px solid rgba(255, 40, 40, 0.15); box-shadow: 0 4px 24px rgba(0,0,0,0.18); } .profile-section img { width: 64px; height: 64px; object-fit: cover; border-radius: 50%; box-shadow: 0 2px 12px rgba(255,40,40,0.12); border: 3px solid #fff2; transition: transform 0.3s ease; } .profile-section img:hover { transform: scale(1.1); } .profile-section strong { font-size: 1.5rem; color: #ff1111; font-weight: 700; letter-spacing: 1px; display: block; margin-bottom: 2px; } .profile-section small, .profile-section a { font-size: 1rem; color: #e0e0e0 !important; opacity: 0.95; } .search-container { background: #23243a; padding: 24px 24px 18px 24px; border-bottom: 1px solid rgba(255, 40, 40, 0.13); margin-bottom: 24px; border-radius: 14px; box-shadow: 0 2px 12px rgba(0,0,0,0.10); max-width: 600px; margin-left: auto; margin-right: auto; } #searchInput, .form-select { width: 100%; padding: 12px; border: 1.5px solid rgba(255, 40, 40, 0.13); border-radius: 8px; background-color: #181818; color: #fff; margin-bottom: 15px; transition: none; } #searchInput:focus, .form-select:focus { outline: none; border-color: #ff1111; box-shadow: none; } #searchInput::placeholder { color: #b0b0b0; } label { color: #e0e0e0; margin-bottom: 8px; display: block; } .styled-table { width: 100%; border-collapse: separate; border-spacing: 0; margin: 25px 0; font-size: 1.05em; background: #23243a; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 24px rgba(0,0,0,0.18); } .styled-table thead tr { background: linear-gradient(90deg, #ff1111 60%, #b21f1f 100%); color: #fff; text-align: left; font-weight: bold; box-shadow: 0 2px 8px rgba(255,17,17,0.10); } .styled-table th, .styled-table td { padding: 16px 18px; } .styled-table tbody tr { border-bottom: 1px solid #2d2d2d; transition: background 0.2s; } .styled-table tbody tr:nth-of-type(even) { background-color: #23243a; } .styled-table tbody tr:nth-of-type(odd) { background-color: #181818; } .styled-table tbody tr:hover { background: #2d2d2d; } .styled-table th { font-size: 1.08em; letter-spacing: 0.5px; border-bottom: 2px solid #ff1111; } .styled-table td { font-size: 1em; color: #e0e0e0; vertical-align: middle; } .badge-modalidade { display: inline-flex; align-items: center; gap: 6px; font-size: 0.98em; font-weight: 600; border-radius: 16px; padding: 6px 14px; background: #181818; color: #fff; border: 1.5px solid #ff1111; box-shadow: 0 1px 4px rgba(255,17,17,0.08); } .badge-futebol { background: #1e7e34; border-color: #1e7e34; } .badge-futsal { background: #007bff; border-color: #007bff; } .badge-volei { background: #ffb300; border-color: #ffb300; color: #23243a; } .badge-basquete { background: #ff5722; border-color: #ff5722; } .badge-tenis { background: #00bcd4; border-color: #00bcd4; } .badge-xadrez { background: #6d4c41; border-color: #6d4c41; } .bottom-nav { box-shadow: 0 -4px 24px rgba(0,0,0,0.18); background: rgba(26,26,26,0.98); z-index: 1000; border-top: 1.5px solid rgba(255, 40, 40, 0.18); backdrop-filter: blur(2px); position: fixed; bottom: 0; left: 0; width: 100%; } .nav-icon { width: 34px; height: 34px; transition: transform 0.3s, filter 0.3s; filter: grayscale(100%); } .nav-icon:hover { transform: scale(1.13); filter: grayscale(0%); } .nav-link small { font-size: 13px; color: #fff; margin-top: 4px; display: block; transition: color 0.3s; font-weight: 500; } .nav-link:hover small { color: #ff1111; } .nav-link { text-decoration: none; color: inherit; } @media (max-width: 700px) { body { padding-bottom: 100px; } .profile-section { padding: 18px 0 12px 0; } .profile-section img { width: 44px; height: 44px; } .search-container { padding: 12px 6px 8px 6px; } .styled-table th, .styled-table td { padding: 8px 6px; font-size: 0.95em; } } </style>
</head>
<body class="bg-dark text-white pb-5">

<div class="profile-section">
    <img src="../Imagens/favicon.png" alt="Logo">
    <div class="profile-text">
        <strong>Pesquisar Campeonatos</strong>
        <small>Encontre torneios por nome ou modalidade</small>
    </div>
</div>

<div class="search-container mt-4 mb-4">
<form id="filtroForm" method="GET">
            <input type="text" id="searchInput" name="nome" class="search-input" 
                   placeholder="Digite para pesquisar..." 
                   value="<?= htmlspecialchars($nomePesquisa) ?>" autocomplete="off">
            <select name="nicho" id="nicho" class="form-select nicho-select">
                <option value="">Todas Modalidades</option>
                <option value="Futebol" <?= $nichoSelecionado === 'Futebol' ? 'selected' : '' ?>>Futebol</option>
                <option value="Futsal" <?= $nichoSelecionado === 'Futsal' ? 'selected' : '' ?>>Futsal</option>
                <option value="Vôlei" <?= $nichoSelecionado === 'Vôlei' ? 'selected' : '' ?>>Vôlei</option>
                <option value="Basquete" <?= $nichoSelecionado === 'Basquete' ? 'selected' : '' ?>>Basquete</option>
                <option value="Tênis de mesa" <?= $nichoSelecionado === 'Tênis de mesa' ? 'selected' : '' ?>>Tênis de mesa</option>
                <option value="Xadrez" <?= $nichoSelecionado === 'Xadrez' ? 'selected' : '' ?>>Xadrez</option>
            </select>
    </form>
    <div id="error"></div>
</div>
    
<div id="results" class="container">
        <?php if (!empty($campeonatos)): ?>
        <div class="table-responsive">
        <table class="styled-table">
            <thead>
                <tr>
                <th>Nome do campeonato</th>
                <th>Nome do dono</th>
                <th>Modalidade</th>
                <th>Endereço</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($campeonatos as $campeonato): ?>
                <tr>
                    <td><?= htmlspecialchars($campeonato->nome) ?></td>
                    <td><?= htmlspecialchars($campeonato->nome_dono) ?></td>
                <td><?= getModalidadeBadge($campeonato->nicho) ?></td>
                    <td><?= htmlspecialchars($campeonato->logradouro) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
            </table>
        </div>
        <?php else: ?>
<p class="text-center mt-4"><?= $nomePesquisa ? 'Nenhum campeonato encontrado.' : 'Nenhum campeonato cadastrado.' ?></p>
<?php endif; ?>
    </div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const nichoSelect = document.getElementById('nicho');
    const resultsDiv = document.getElementById('results');
    const errorDiv = document.getElementById('error');
    document.getElementById('filtroForm').addEventListener('submit', function(e) {
        e.preventDefault();
        buscarCampeonatos();
    });
    searchInput.addEventListener('input', function() {
        buscarCampeonatos();
    });
    nichoSelect.addEventListener('change', function() {
        buscarCampeonatos();
    });
    function buscarCampeonatos() {
        const nome = searchInput.value;
        const nicho = nichoSelect.value;
        const params = new URLSearchParams({ nome, nicho }).toString();
        window.history.pushState({}, '', `search.php?${params}`);
        fetch(`../router.php?rota=buscar_ajax&nome=${encodeURIComponent(nome)}&nicho=${encodeURIComponent(nicho)}`)
            .then(response => {
                if (!response.ok) throw new Error('Erro na rede');
                return response.text();
            })
            .then(html => {
                resultsDiv.innerHTML = html;
                errorDiv.style.display = 'none';
            })
            .catch(error => {
                errorDiv.textContent = 'Erro ao buscar campeonato: ' + error.message;
                errorDiv.style.display = 'block';
                console.error('Erro:', error);
            });
    }
    buscarCampeonatos();
});
</script>

    <div class="barra">
        <nav class="bottom-nav d-flex justify-content-around py-2">
            <a href="../painel.php" class="nav-link text-center">
                <div>
              <img src="../Imagens/home.png" class="nav-icon">
                </div>
                <small>Home</small>
            </a>
            <a href="search.php" class="nav-link text-center">
                <div>
                <img src="../Imagens/lupa.png" class="nav-icon">
                </div>
                <small>Pesquisar</small>
            </a>
            <a href="config.php" class="nav-link text-center">
                <div>
              <img src="../Imagens/configuraçoes.png" class="nav-icon">
                </div>
                <small>Ajustes</small>
            </a>
        </nav>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
