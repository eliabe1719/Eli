<?php
require_once __DIR__ . '/../controllers/Controller.php';
// Inicie a sessão ANTES de qualquer output
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$controller = new Controller();
$todosCampeonatos = $controller->listar();

// Filtra campeonatos pelo nome da empresa logada
$campeonatos = array_filter($todosCampeonatos, function($camp) {
    return $camp->nome_dono === ($_SESSION['empresa_nome'] ?? '');
});

$nome = $_SESSION['empresa_nome'] ?? '';
$email = $_SESSION['empresa_email'] ?? '';
$cnpj = $_SESSION['empresa_cnpj'] ?? '';
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Campeonatos</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../Imagens/favicon.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style> body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: linear-gradient(135deg, #181818 60%, #23243a 100%); color: #f5f5f5; line-height: 1.6; padding-bottom: 80px; min-height: 100vh; } .profile-section { background: linear-gradient(135deg, #23243a 60%, #181818 100%); padding: 32px 0 24px 0; text-align: center; border-bottom: 1px solid rgba(255, 40, 40, 0.15); box-shadow: 0 4px 24px rgba(0,0,0,0.18); } .profile-section img { width: 64px; height: 64px; object-fit: cover; border-radius: 50%; box-shadow: 0 2px 12px rgba(255,40,40,0.12); border: 3px solid #fff2; transition: transform 0.3s ease; } .profile-section img:hover { transform: scale(1.1); } .profile-section strong { font-size: 1.5rem; color: #ff1111; font-weight: 700; letter-spacing: 1px; display: block; margin-bottom: 2px; } .profile-section small, .profile-section a { font-size: 1rem; color: #e0e0e0 !important; opacity: 0.95; } .btn-outline-danger { font-size: 15px; padding: 7px 18px; border: 1.5px solid #ff1111; color: #ff1111; background: transparent; border-radius: 8px; font-weight: 600; transition: background 0.3s, color 0.3s; box-shadow: 0 2px 8px rgba(255,17,17,0.08); } .btn-outline-danger i { margin-right: 6px; } .btn-outline-danger:hover { background: #ff1111; color: #fff; } .btn-config { background: linear-gradient(135deg, #23243a 60%, #181818 100%); border: 1.5px solid rgba(255, 40, 40, 0.13); border-radius: 14px; padding: 18px 18px 12px 18px; margin-bottom: 18px; transition: none; text-align: left; } .btn-config h5 { color: #ff1111; font-size: 1.1rem; font-weight: 700; margin: 0 0 2px 0; letter-spacing: 0.5px; } .btn-config small { color: #e0e0e0; font-size: 0.95rem; opacity: 0.95; } .status-badge { background: #ff1111; color: #fff !important; font-size: 0.95rem; padding: 6px 16px; border-radius: 20px; font-weight: 600; box-shadow: none; border: none; } .bottom-nav { box-shadow: 0 -4px 24px rgba(0,0,0,0.18); background: rgba(26,26,26,0.98); z-index: 1000; border-top: 1.5px solid rgba(255, 40, 40, 0.18); backdrop-filter: blur(2px); position: fixed; bottom: 0; left: 0; width: 100%; } .nav-icon { width: 34px; height: 34px; transition: transform 0.3s, filter 0.3s; filter: grayscale(100%); } .nav-icon:hover { transform: scale(1.13); filter: grayscale(0%); } .nav-link small { font-size: 13px; color: #fff; margin-top: 4px; display: block; transition: color 0.3s; font-weight: 500; } .nav-link:hover small { color: #ff1111; } .nav-link { text-decoration: none; color: inherit; } .styled-table { width: 100%; border-collapse: collapse; margin: 25px 0; font-size: 1.05em; background: #23243a; border-radius: 12px 12px 0 0; overflow: hidden; box-shadow: 0 2px 12px rgba(0,0,0,0.12); } .styled-table thead tr { background-color: #ff1111; color: #ffffff; text-align: left; font-weight: bold; } .styled-table th, .styled-table td { padding: 12px 15px; } .styled-table tbody tr { border-bottom: 1px solid #dddddd; } .styled-table tbody tr:nth-of-type(even) { background-color: #2d2d2d; } .styled-table tbody tr:last-of-type { border-bottom: 2px solid #ff1111; } .styled-table a { color: #ff1111; font-weight: 600; text-decoration: none; transition: color 0.2s; } .styled-table a:hover { color: #fff; background: #ff1111; border-radius: 6px; padding: 2px 8px; } .btn-voltar { margin-top: 24px; background: #23243a; color: #fff; border: 1.5px solid #ff1111; border-radius: 8px; padding: 10px 28px; font-size: 1.1rem; font-weight: 600; transition: background 0.3s, color 0.3s; } .btn-voltar:hover { background: #ff1111; color: #fff; } @media (max-width: 700px) { body { padding-bottom: 100px; } .profile-section { padding: 18px 0 12px 0; } .profile-section img { width: 44px; height: 44px; } .styled-table th, .styled-table td { padding: 8px 6px; font-size: 0.95em; } .btn-voltar { width: 100%; padding: 10px 0; } } </style>
</head>
<body>

<div class="profile-section">
    <img src="../Imagens/favicon.png" alt="Logo">
    <div class="profile-text">
        <strong><?= htmlspecialchars($nome) ?></strong><br>
        <small><?= htmlspecialchars($email) ?></small><br>
        <?php if (isset($_SESSION['empresa_cnpj'])): ?>
            <small>CNPJ: <?= htmlspecialchars($cnpj) ?></small><br>
        <?php endif; ?>
        <a href="../login/logout.php" class="sair"> <small>Sair</small> </a>
    </div>
</div>

<div class="container mt-4">
    <h2 class="mb-4" style="color:#ff1111; font-weight:700;">Meus Campeonatos</h2>

    <?php if (!empty($campeonatos)): ?>
        <div class="table-responsive">
        <table class="styled-table">
            <thead>
            <tr>
                <th>Nome do campeonato</th>
                <th>Nome do dono</th>
                <th>Modalidade</th>
                <th>Endereço</th>
                <th colspan="2">Ações</th>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($campeonatos as $campeonato): ?>
            <tr>
                <td><?= htmlspecialchars($campeonato->nome) ?></td>
                <td><?= htmlspecialchars($campeonato->nome_dono) ?></td>
                <td><?= htmlspecialchars($campeonato->nicho) ?></td>
                <td><?= htmlspecialchars($campeonato->logradouro) ?></td>
                <td>
                    <a href="/SporTTown/router.php?rota=deletar&nome=<?= urlencode($campeonato->nome) ?>" 
                    onclick="return confirm('Tem certeza que deseja excluir este campeonato?');">
                    Excluir
                    </a>
                </td>
                <td>
                    <a href="/SporTTown/router.php?rota=formAtualizar&nome=<?= urlencode($campeonato->nome) ?>">
                    Atualizar
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
    <?php else: ?>
        <p class="text-center mt-4">Nenhum campeonato cadastrado.</p>
    <?php endif; ?>

    <button onclick="window.location.href='/SporTTown/Ações/config.php'" class="btn-voltar">
        Voltar
    </button>
</div>

<div class="barra">
    <nav class="bottom-nav d-flex justify-content-around py-2">
        <a href="../painel.php" class="nav-link text-center">
            <div>
              <img src="../Imagens/home.png" class="nav-icon">
            </div>
            <small>Home</small>
        </a>
        <a href="../Ações/search.php" class="nav-link text-center">
            <div>
                <img src="../Imagens/lupa.png" class="nav-icon">
            </div>
            <small>Pesquisar</small>
        </a>
        <a href="#" class="nav-link text-center">
            <div>
              <img src="../Imagens/configuraçoes.png" class="nav-icon">
            </div>
            <small>Ajustes</small>
        </a>
    </nav>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>