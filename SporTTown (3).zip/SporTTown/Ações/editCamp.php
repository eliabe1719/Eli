<?php
require_once __DIR__ . '/../controllers/Controller.php';

$controller = new Controller();

// Recebe o nome do campeonato que será editado
$nome_campeonato = $_GET['nome'] ?? null;

if (!$nome_campeonato) {
    echo "<p>Campeonato não especificado.</p>";
    echo '<button onclick="window.location.href=\'/SporTTown/router.php?rota=listar\'">Voltar</button>';
    exit;
}

// Busca os dados do campeonato
$campeonato = $controller->buscarPorNome($nome_campeonato);

if (!$campeonato) {
    echo "<p>Campeonato não encontrado.</p>";
    echo '<button onclick="window.location.href=\'/SporTTown/router.php?rota=listar\'">Voltar</button>';
    exit;
}

// Se for array, pega o primeiro item (supondo que possa retornar array de resultados)
if (is_array($campeonato)) {
    $campeonato = !empty($campeonato) ? $campeonato[0] : null;
    if (!$campeonato) {
        echo "<p>Campeonato não encontrado.</p>";
        echo '<button onclick="window.location.href=\'/SporTTown/../router.php?rota=listar\'">Voltar</button>';
        exit;
    }
}

// Agora acessamos as propriedades como objeto
$nome_ = $campeonato->nome_dono ?? '';
$cnpj_ = $campeonato->cnpj ?? '';
$email_ = $campeonato->email ?? '';
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../Imagens/favicon.png">
    <title>Edição de Campeonatos</title>
    <style>
        :root {
            --primary: #1a1a1a;
            --secondary: #ff1111;
            --dark: #2d2d2d;
            --light: #f8f9fa;
            --gray: #b0b0b0;
            --success: #155724;
            --error: #721c24;
            --shadow: 0 4px 24px rgba(0,0,0,0.5);
            --transition: all 0.3s ease;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #1a1a1a, #2d2d2d 80%);
            color: var(--light);
            padding: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        
        html, body {
            height: 100%;
        }
        
        .container {
            max-width: 600px;
            width: 100%;
            margin: auto;
            background: var(--dark);
            border-radius: 15px;
            box-shadow: var(--shadow);
            overflow: hidden;
            animation: fadeIn 0.8s ease-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        header {
            background: linear-gradient(to right, var(--primary), #363636);
            color: var(--light);
            padding: 25px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        
        header::after {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" preserveAspectRatio="none"><polygon points="0,100 100,0 100,100" fill="rgba(255,255,255,0.1)"/></svg>');
            background-size: cover;
            opacity: 0.3;
        }
        
        .profile-section {
            display: flex;
            align-items: center;
            padding: 10px;
            background-color: black;
            color: azur;
        }

        .profile-section img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
        }

        .profile-text {
            margin-left: 10px;
        }


        header h1 {
            font-size: 2rem;
            margin-bottom: 10px;
            position: relative;
            z-index: 1;
            text-shadow: 0 2px 4px rgba(0,0,0,0.3);
        }
        
        header p {
            font-size: 1.1rem;
            opacity: 0.9;
            max-width: 600px;
            margin: 0 auto;
            position: relative;
            z-index: 1;
        }
        
        .content {
            padding: 30px;
        }
        
        .form-section {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px dashed #444;
        }
        
        .form-section h2 {
            color: var(--secondary);
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid var(--secondary);
            display: flex;
            align-items: center;
        }
        
        .form-section h2 i {
            margin-right: 10px;
            font-size: 1.5rem;
        }
        
        .form-group {
            margin-bottom: 25px;
            position: relative;
        }
        
        .form-group input[type="password"] {
            padding-right: 40px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--light);
            display: flex;
            align-items: center;
        }
        
        label i {
            margin-right: 8px;
            font-size: 1.1rem;
        }
        
        .required::after {
            content: " *";
            color: var(--secondary);
        }
        
        input, select {
            width: 100%;
            padding: 14px;
            border: 2px solid #444;
            border-radius: 8px;
            font-size: 16px;
            transition: var(--transition);
            background-color: #232323;
            color: #fff;
        }
        
        input:focus, select:focus {
            border-color: var(--secondary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(255, 17, 17, 0.15);
            background-color: #181818;
            color: #fff;
        }
        
        input[readonly], .form-control-plaintext {
            color: #232323 !important;
            background-color: #232323 !important;
        }
        
        input#cnpj, input#email {
            color: #232323 !important;
            background-color: #232323 !important;
        }
        
        ::placeholder {
            color: #bbb;
            opacity: 1;
        }
        
        .row {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
        }
        
        .col {
            flex: 1;
        }
        
        .file-upload {
            border: 2px dashed var(--primary);
            border-radius: 10px;
            padding: 25px;
            text-align: center;
            background-color: #f8f9fa;
            cursor: pointer;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }
        
        .file-upload:hover {
            background-color: #e9ecef;
            border-color: var(--secondary);
        }
        
        .file-upload p {
            margin-top: 10px;
            font-size: 14px;
            color: var(--gray);
        }
        
        #file-name {
            margin-top: 10px;
            font-size: 14px;
            font-weight: 500;
            color: var(--primary);
            word-break: break-word;
        }
        
        .btn {
            background: linear-gradient(to right, var(--secondary), #a00);
            color: #fff !important;
            border: none;
            padding: 16px 30px;
            font-size: 18px;
            font-weight: 600;
            border-radius: 8px;
            cursor: pointer;
            width: 100%;
            transition: var(--transition);
            text-transform: uppercase;
            letter-spacing: 1px;
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
            overflow: hidden;
        }
        
        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
            background: linear-gradient(to right, #a00, var(--secondary));
            color: #fff !important;
        }
        
        .btn:active {
            transform: translateY(0);
            color: #fff !important;
        }
        
        .btn::after {
            content: "";
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent);
            transition: 0.5s;
        }
        
        .btn:hover::after {
            left: 100%;
        }
        
        .notification {
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
            text-align: center;
            font-weight: 500;
            display: none;
            animation: slideIn 0.3s ease-out;
        }
        
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .success {
            background-color: #232;
            color: #7fff7f;
            border: 1px solid #393;
        }
        
        .error {
            background-color: #400;
            color: #ff7f7f;
            border: 1px solid #a00;
        }
        
        footer {
            text-align: center;
            padding: 20px;
            color: var(--gray);
            font-size: 14px;
            border-top: 1px solid #eee;
            background-color: #f8f9fa;
        }
        
        .cep-btn {
            background: var(--primary);
            color: white;
            border: none;
            padding: 14px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: background 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        
        .cep-btn:hover {
            background: var(--dark);
        }
        
        .progress-bar {
            height: 5px;
            background-color: #e9ecef;
            border-radius: 10px;
            margin-top: 10px;
            overflow: hidden;
            display: none;
        }
        
        .progress {
            height: 100%;
            background-color: var(--primary);
            width: 0%;
            transition: width 0.3s ease;
        }
        
        .password-toggle {
            position: absolute;
            right: 18px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
            cursor: pointer;
            font-size: 1.2rem;
            height: 1.2em;
            display: flex;
            align-items: center;
            justify-content: center;
            line-height: 1;
            pointer-events: auto;
        }
        
        @media (max-width: 500px) {
            .container {
                padding: 0;
                border-radius: 0;
                box-shadow: none;
            }
            header h1 {
                font-size: 1.3rem;
            }
            .content {
                padding: 12px;
            }
            .btn {
                padding: 12px 10px;
                font-size: 16px;
            }
        }
        
        input#cnpj.form-control-plaintext,
        input#email.form-control-plaintext,
        input#cnpj[readonly],
        input#email[readonly] {
            color: #1a1a1a !important;
            background-color: #fff !important;
        }
        input#cnpj::placeholder,
        input#email::placeholder {
            color: #1a1a1a !important;
            opacity: 1;
        }
        input#cnpj::-webkit-input-placeholder,
        input#email::-webkit-input-placeholder {
            color: #1a1a1a !important;
        }
        input#cnpj:-moz-placeholder,
        input#email:-moz-placeholder {
            color: #1a1a1a !important;
        }
        input#cnpj::-moz-placeholder,
        input#email::-moz-placeholder {
            color: #1a1a1a !important;
        }
        input#cnpj:-ms-input-placeholder,
        input#email:-ms-input-placeholder {
            color: #1a1a1a !important;
        }
        
        /* Campos dos dados do usuário sempre brancos */
        .input-user-data,
        .input-user-data[readonly],
        .input-user-data.form-control-plaintext {
            color: #fff !important;
            background-color: #fff !important;
        }
        .input-user-data::placeholder {
            color: #fff !important;
            opacity: 1;
        }
        .input-user-data::-webkit-input-placeholder { color: #fff !important; }
        .input-user-data:-moz-placeholder { color: #fff !important; }
        .input-user-data::-moz-placeholder { color: #fff !important; }
        .input-user-data:-ms-input-placeholder { color: #fff !important; }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <h1><i class="fas fa-trophy"></i> Edição de Campeonato</h1>
            <p>Atualize os campos necessários para modificar seu campeonato</p>
        </header>
        <?php if (isset($_GET['sucesso']) && $_GET['sucesso'] == 1): ?>
        <p class="success-message">Campeonato atualizado com sucesso!</p>
        <?php endif; ?>
        <div class="content">
            <form id="cadastroForm" action="../router.php?rota=atualizar_campeonato" method="POST">
                <input type="hidden" name="nome_original" value="<?= htmlspecialchars($nome_campeonato, ENT_QUOTES, 'UTF-8') ?>">
                
                <!-- Seção 2: Endereço -->
                <div class="form-section">
                    <h2><i class="fas fa-map-marker-alt"></i> Endereço</h2>
                    
                    <div class="form-group">
                        <label for="cep" class="required"><i class="fas fa-map-pin"></i> CEP</label>
                        <div class="row">
                            <div class="col">
                                <input type="text" id="cep" name="cep" placeholder="Digite o CEP" maxlength="9" required 
                                value="<?= htmlspecialchars($campeonato->cep ?? '', ENT_QUOTES, 'UTF-8') ?>">
                            </div>
                            <div class="col">
                                <button type="button" class="cep-btn" id="buscarCep">
                                    <i class="fas fa-search"></i> Buscar Endereço
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="logradouro" class="required"><i class="fas fa-road"></i> Logradouro</label>
                                <input type="text" id="logradouro" name="logradouro" placeholder="Rua, Avenida, etc." required
                                       value="<?= htmlspecialchars($campeonato->logradouro ?? '', ENT_QUOTES, 'UTF-8') ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="bairro" class="required"><i class="fas fa-map"></i> Bairro</label>
                                <input type="text" id="bairro" name="bairro" placeholder="Bairro" required
                                       value="<?= htmlspecialchars($campeonato->bairro ?? '', ENT_QUOTES, 'UTF-8') ?>">
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="cidade" class="required"><i class="fas fa-city"></i> Cidade</label>
                                <input type="text" id="cidade" name="cidade" placeholder="Cidade" required
                                       value="<?= htmlspecialchars($campeonato->cidade ?? '', ENT_QUOTES, 'UTF-8') ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="estado" class="required"><i class="fas fa-flag"></i> Estado</label>
                        <select id="estado" name="estado" required>
                            <option value="">Selecione um estado</option>
                            <!-- Estados com selected no estado atual -->
                            <?php
                            $estados = [
                                'AC' => 'Acre', 'AL' => 'Alagoas', 'AP' => 'Amapá', 'AM' => 'Amazonas',
                                'BA' => 'Bahia', 'CE' => 'Ceará', 'DF' => 'Distrito Federal', 'ES' => 'Espírito Santo',
                                'GO' => 'Goiás', 'MA' => 'Maranhão', 'MT' => 'Mato Grosso', 'MS' => 'Mato Grosso do Sul',
                                'MG' => 'Minas Gerais', 'PA' => 'Pará', 'PB' => 'Paraíba', 'PR' => 'Paraná',
                                'PE' => 'Pernambuco', 'PI' => 'Piauí', 'RJ' => 'Rio de Janeiro', 'RN' => 'Rio Grande do Norte',
                                'RS' => 'Rio Grande do Sul', 'RO' => 'Rondônia', 'RR' => 'Roraima', 'SC' => 'Santa Catarina',
                                'SP' => 'São Paulo', 'SE' => 'Sergipe', 'TO' => 'Tocantins'
                            ];
                            
                            $estadoAtual = $campeonato->estado ?? '';
                            
                            foreach ($estados as $sigla => $nome) {
                                $selected = ($sigla == $estadoAtual) ? 'selected' : '';
                                echo "<option value=\"$sigla\" $selected>$nome</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>
                
                <!-- Seção 3: Dados do Campeonato -->
                <div class="form-section">
                    <h2><i class="fas fa-futbol"></i> Dados do Campeonato</h2>
                    
                    <div class="form-group">
                        <label for="nome" class="required"><i class="fas fa-trophy"></i> Nome do Campeonato</label>
                        <input type="text" id="nome" name="nome" placeholder="Nome do campeonato" required
                               value="<?= htmlspecialchars($campeonato->nome ?? '', ENT_QUOTES, 'UTF-8') ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="nicho" class="required"><i class="fas fa-running"></i> Modalidade Esportiva</label>
                        <select id="nicho" name="nicho" required>
                            <option value="">Selecione uma modalidade</option>
                            <?php
                            $modalidades = [
                                'Futebol', 'Futsal', 'Vôlei', 'Basquete', 'Tênis de mesa', 'Xadrez'
                            ];
                            
                            $modalidadeAtual = $campeonato->nicho ?? '';
                            
                            foreach ($modalidades as $modalidade) {
                                $selected = ($modalidade == $modalidadeAtual) ? 'selected' : '';
                                echo "<option value=\"$modalidade\" $selected>$modalidade</option>";
                            }
                            ?>
                        </select>
                    </div>
                </div>
                
                <!-- Seção 4: Dados de Acesso -->
                <div class="form-section">
                    <h2><i class="fas fa-user-shield"></i> Dados de Acesso</h2>
                    
                    <div class="form-group">
                        <label for="nome_dono" class="required">
                            <i class="fas fa-user"></i> Nome da Empresa
                        </label>
                        <input
                            type="text"
                            id="nome_dono"
                            name="nome_dono"
                            class="form-control-plaintext"
                            value="<?= htmlspecialchars($nome_, ENT_QUOTES, 'UTF-8') ?>"
                            readonly
                        >
                        <input
                            type="hidden"
                            name="nome_dono"
                            value="<?= htmlspecialchars($nome_, ENT_QUOTES, 'UTF-8') ?>"
                        >
                    </div>

                    <div class="form-group">
                        <label for="cnpj" class="required">
                            <i class="fas fa-id-card"></i> CNPJ
                        </label>
                        <input
                            type="text"
                            id="cnpj"
                            name="cnpj"
                            class="form-control-plaintext"
                            value="<?= htmlspecialchars($cnpj_, ENT_QUOTES, 'UTF-8') ?>"
                            readonly
                        >
                        <input
                            type="hidden"
                            name="cnpj"
                            value="<?= htmlspecialchars($cnpj_, ENT_QUOTES, 'UTF-8') ?>"
                        >
                    </div>

                    <div class="form-group">
                        <label for="email" class="required">
                            <i class="fas fa-envelope"></i> Email
                        </label>
                        <input
                            type="text"
                            id="email"
                            name="email"
                            class="form-control-plaintext"
                            value="<?= htmlspecialchars($email_, ENT_QUOTES, 'UTF-8') ?>"
                            readonly
                        >
                        <input
                            type="hidden"
                            name="email"
                            value="<?= htmlspecialchars($email_, ENT_QUOTES, 'UTF-8') ?>"
                        >
                    </div>
                    
                    <div class="form-group">
                        <label for="senha" class="required"><i class="fas fa-lock"></i> Senha</label>
                        <input type="password" id="senha" name="senha" placeholder="Confirme sua senha" required>
                        <i class="fas fa-eye password-toggle" id="togglePassword"></i>
                    </div>
                </div>
                
                <button type="submit" class="btn">
                    <i class="fas fa-save"></i> Atualizar Campeonato
                </button>
                <br>
                <button type="button" class="btn" onclick="window.location.href='/SportTown/painel.php'">
                    <i class="fas fa-arrow-left"></i> Voltar
                </button>
            </form>
            
            <div id="notification" class="notification"></div>
        </div>
        
        <footer>
            <p>Sistema de Cadastro de Campeonatos &copy; <?php echo date('Y'); ?></p>
        </footer>
    </div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
    // — Captura de elementos do DOM —
    const cnpjInput      = document.getElementById('cnpj');
    const cepInput       = document.getElementById('cep');
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput  = document.getElementById('senha');
    const buscarCepBtn   = document.getElementById('buscarCep');
    const form           = document.getElementById('cadastroForm');

    // Verifica existência mínima
    if (!cnpjInput || !cepInput || !form) {
        console.warn('Elementos essenciais não encontrados.');
        return;
    }

    // — Máscara CNPJ —
    cnpjInput.addEventListener('input', function(e) {
        let pos = e.target.selectionStart;
        let v   = e.target.value.replace(/\D/g, '').slice(0,14);
        let f   = '';
        for (let i = 0; i < v.length; i++) {
        if (i === 2 || i === 5) f += '.';
        if (i === 8) f += '/';
        if (i === 12) f += '-';
        f += v[i];
        }
        e.target.value = f;
        // Ajusta cursor
        if (f.length > v.length && [3,6,10,15].includes(pos)) pos++;
        if (f.length < v.length && [3,6,10,15].includes(pos)) pos--;
        e.target.setSelectionRange(pos, pos);
    });

    // — Máscara CEP —
    cepInput.addEventListener('input', function(e) {
        let v = e.target.value.replace(/\D/g, '').slice(0,8);
        if (v.length > 5) v = v.replace(/(\d{5})(\d)/, '$1-$2');
        e.target.value = v;
    });

    // — Toggle mostrar/ocultar senha —
    if (togglePassword && passwordInput) {
        togglePassword.addEventListener('click', function() {
        const type = passwordInput.type === 'password' ? 'text' : 'password';
        passwordInput.type = type;
        togglePassword.classList.toggle('fa-eye');
        togglePassword.classList.toggle('fa-eye-slash');
        });
    }

    // — Busca de CEP —
    if (buscarCepBtn) {
        buscarCepBtn.addEventListener('click', function() {
        const cep = cepInput.value.replace(/\D/g, '');
        if (cep.length !== 8) {
            showNotification('CEP inválido! Digite 8 números.', 'error');
            return;
        }
        showNotification('Buscando endereço…', 'success');
        fetch(`https://viacep.com.br/ws/${cep}/json/`)
            .then(r => r.json())
            .then(data => {
            if (data.erro) {
                showNotification('CEP não encontrado!', 'error');
            } else {
                document.getElementById('logradouro').value = data.logradouro || '';
                document.getElementById('bairro').value   = data.bairro   || '';
                document.getElementById('cidade').value   = data.localidade || '';
                document.getElementById('estado').value   = data.uf       || '';
                showNotification('Endereço carregado!', 'success');
            }
            })
            .catch(() => {
            showNotification('Erro ao buscar CEP.', 'error');
            });
        });
    }

    // — Envio do formulário —
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        hideNotification();

        const cnpj        = cnpjInput.value.replace(/\D/g, '');
        const empresa     = document.getElementById('nome_dono')?.value || '';
        const cepVal      = cepInput.value.replace(/\D/g, '');
        const senha       = passwordInput?.value || '';

        // Validações
        if (cnpj.length !== 14) {
        showNotification('CNPJ inválido! Digite 14 números.', 'error');
        return;
        }
        if (!empresa) {
        showNotification('Nome da empresa é obrigatório!', 'error');
        return;
        }
        if (cepVal.length !== 8) {
        showNotification('CEP inválido! Digite 8 números.', 'error');
        return;
        }
        if (senha.length < 6) {
        showNotification('A senha deve ter pelo menos 6 caracteres.', 'error');
        return;
        }

        // Se tudo ok, envia o formulário
        this.submit();
    });

    // — Funções de notificação —
    function showNotification(msg, type) {
        const n = document.getElementById('notification');
        if (!n) return;
        n.textContent = msg;
        n.className   = `notification ${type}`;
        n.style.display = 'block';
        n.scrollIntoView({ behavior: 'smooth', block: 'center' });
        if (type === 'success') setTimeout(() => n.style.display = 'none', 5000);
    }
    function hideNotification() {
        const n = document.getElementById('notification');
        if (n) n.style.display = 'none';
    }
    });
</script>
</body>
</html>