<?php
// Aqui deve aparacer: Página do campeonato: Copa Amélia
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include('../models/Model.php');
$model = new Model();
$pdo = $model->getConnect();

// Recupera dados da sessão
$nome = $_SESSION['empresa_nome'] ?? '';
$email = $_SESSION['empresa_email'] ?? '';
$cnpj = $_SESSION['empresa_cnpj'] ?? '';

require_once('../configs/protected.php');
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../Imagens/favicon.png">
    <title>Copa Amélia</title>
    <link rel="stylesheet" href="../css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="profile-section">
        <div class="profile-text">
            <strong><?= htmlspecialchars($nome) ?></strong><br>
            <small><?= htmlspecialchars($email) ?></small><br>   
            <?php if (isset($_SESSION['empresa_cnpj'])): ?>
                <small>CNPJ: <?= htmlspecialchars($cnpj) ?></small><br>
            <?php endif; ?>
            <a href="../login/logout.php" class="sair"> <small>Sair</small> </a>
        </div>
    </div>
</body>
</html>