<?php
require_once 'controllers/Controller.php';

$controller = new Controller();

$rota = $_GET['rota'] ?? 'listar'; // Se não tiver definida, define com a rota padrão

// Processa requisições POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if ($rota == 'cadastrar') {
        $controller->cadastrar();
    }elseif ($rota == 'empresa') {
        $controller->empresa();
    }elseif ($rota == 'camps') {
        $controller->camps();
    }
    exit;
}

// Processa requisições GET
switch($rota) {
    case 'buscar_ajax':
    try {
        function getModalidadeBadge($nicho) {
            $icons = [
                'Futebol' => '<img src="/SporTTown/Imagens/futebol.png" alt="Futebol" style="width:22px;vertical-align:middle;">',
                'Futsal' => '<img src="/SporTTown/Imagens/futsal.png" alt="Futsal" style="width:22px;vertical-align:middle;">',
                'Vôlei' => '<img src="/SporTTown/Imagens/vôlei.png" alt="Vôlei" style="width:22px;vertical-align:middle;">',
                'Basquete' => '<img src="/SporTTown/Imagens/basquete.png" alt="Basquete" style="width:22px;vertical-align:middle;">',
                'Tênis de mesa' => '<img src="/SporTTown/Imagens/tenis de mesa.png" alt="Tênis de mesa" style="width:22px;vertical-align:middle;">',
                'Xadrez' => '<img src="/SporTTown/Imagens/icons8-configuração-50 (1).png" alt="Xadrez" style="width:22px;vertical-align:middle;">',
            ];
            $classes = [
                'Futebol' => 'badge-modalidade badge-futebol',
                'Futsal' => 'badge-modalidade badge-futsal',
                'Vôlei' => 'badge-modalidade badge-volei',
                'Basquete' => 'badge-modalidade badge-basquete',
                'Tênis de mesa' => 'badge-modalidade badge-tenis',
                'Xadrez' => 'badge-modalidade badge-xadrez',
            ];
            $icon = $icons[$nicho] ?? '';
            $class = $classes[$nicho] ?? 'badge-modalidade';
            return '<span class="' . $class . '">' . $icon . htmlspecialchars($nicho) . '</span>';
        }

        $nomePesquisa = $_GET['nome'] ?? '';
        $nichoBuscar = $_GET['nicho'] ?? '';
        $campeonatos = $controller->buscarCampeonatosPorFiltros($nomePesquisa, $nichoBuscar);

        if (!empty($campeonatos)): ?>
            <table class="styled-table">
                <thead>
                    <tr>
                        <th>Nome do campeonato</th>
                        <th>Nome do dono</th>
                        <th>Modalidade</th>
                        <th>Endereço</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($campeonatos as $campeonato): ?>
                    <tr>
                        <td><?= htmlspecialchars($campeonato->nome) ?></td>
                        <td><?= htmlspecialchars($campeonato->nome_dono) ?></td>
                        <td><?= getModalidadeBadge($campeonato->nicho) ?></td>
                        <td><?= htmlspecialchars($campeonato->logradouro) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p><?= $nomePesquisa ? 'Nenhum campeonato cadastrado.' : 'Nenhum campeonato cadastrado.' ?></p>
        <?php endif;

    } catch(Exception $e) {
        http_response_code(500);
        echo "Erro no servidor: " . $e->getMessage();
    }
    exit;

    case 'cadastrar':
        require_once 'cadastros/cadastrar.php';
        break;
    case 'empresa':
        require_once 'cadastros/empresa.php';
        break;
    case 'camps':
        require_once 'cadastros/camps.php';
        break;
    case 'listar':
    require_once __DIR__ . '/Ações/saveCamp.php';
    break;
    case 'deletar':
        $controller->deletar();
    break;
    case 'confirmarDeletar':
        $controller->deletar();
    break; 
    case 'formAtualizar':
    require_once 'Ações/editCamp.php';
    break;
    
    case 'atualizar':
        $controller->atualizar();
    break;    
}

?>