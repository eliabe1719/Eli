<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include('../models/Model.php');
$model = new Model();
$pdo = $model->getConnect();

// Recupera dados da sessão
$nome_ = $_SESSION['empresa_nome'] ?? '';
$email_ = $_SESSION['empresa_email'] ?? '';
$cnpj_ = $_SESSION['empresa_cnpj'] ?? '';

require_once('../configs/protected.php');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="../Imagens/favicon.png">
    <title>Cadastros de Campeonatos</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            background: linear-gradient(135deg, #1a1a1a, #2d2d2d 80%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        html, body {
            height: 100%;
        }
        .container {
            background: #23243a;
            padding: 30px 20px;
            border-radius: 14px;
            width: 100%;
            max-width: 900px;
            box-shadow: none;
            animation: none;
            margin: auto;
        }
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        header {
            color: #fff;
            text-align: center;
            margin-bottom: 20px;
        }
        header h1 {
            font-size: 2rem;
            margin-bottom: 10px;
        }
        header p {
            font-size: 1.1rem;
            opacity: 0.9;
        }
        .profile-section {
            display: flex;
            align-items: center;
            padding: 10px;
            background-color: black;
            color: azure;
        }
        .profile-section img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
        }
        .profile-text {
            margin-left: 10px;
        }
        .content {
            padding: 20px 0 0 0;
        }
        .form-section {
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #23243a;
        }
        .form-section h2 {
            color: #ff1111;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #ff1111;
            display: flex;
            align-items: center;
            font-weight: 700;
        }
        .form-section h2 i {
            margin-right: 10px;
            font-size: 1.5rem;
        }
        .form-group {
            margin-bottom: 25px;
            position: relative;
        }
        label {
            color: #e0e0e0;
            font-weight: 500;
            margin-bottom: 5px;
            font-size: 14px;
            display: flex;
            align-items: center;
        }
        label i {
            margin-right: 8px;
            font-size: 1.1rem;
        }
        .required::after {
            content: " *";
            color: #ff3333;
        }
        input, select {
            width: 100%;
            padding: 12px;
            background-color: #181818;
            color: #fff;
            border: 1.5px solid rgba(255, 17, 17, 0.13);
            border-radius: 8px;
            font-size: 15px;
            transition: none;
        }
        input:focus, select:focus {
            outline: none;
            background-color: #23243a;
            border-color: #ff1111;
            box-shadow: none;
        }
        ::placeholder {
            color: #888;
            opacity: 1;
        }
        .row {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
        }
        .col {
            flex: 1;
        }
        .btn {
            padding: 14px 20px;
            background: linear-gradient(to right, #ff1111, #a00);
            color: #fff !important;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            transition: none;
            width: 100%;
            margin-bottom: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .btn:hover {
            background: linear-gradient(to right, #a00, #ff1111);
            color: #fff !important;
        }
        .notification {
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
            text-align: center;
            font-weight: 500;
            display: none;
            background-color: #23243a;
            color: #fff;
        }
        .success-message {
            text-align: center;
            color: #2ecc71;
            margin-bottom: 15px;
            font-weight: bold;
        }
        .password-toggle {
            position: absolute;
            right: 15px;
            top: 40px;
            cursor: pointer;
            color: #aaa;
        }
        @media (max-width: 768px) {
            .row {
                flex-direction: column;
                gap: 0;
            }
            header h1 {
                font-size: 1.5rem;
            }
            .container {
                padding: 15px 5px;
            }
            .btn {
                font-size: 14px;
            }
        }
        /* Adiciona uma classe para os campos de dados do usuário */
        .input-user-data {
            background-color: #181818 !important;
            color: #fff !important;
        }
        #senha.input-user-data {
            background-color: #181818 !important;
            color: #fff !important;
        }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <h1><i class="fas fa-trophy"></i> Cadastro de Campeonatos</h1>
            <p>Preencha todos os campos obrigatórios para registrar seu campeonato</p>
        </header>
        <?php if (isset($_GET['sucesso']) && $_GET['sucesso'] == 1): ?>
        <p class="success-message">Campeonato cadastrado com sucesso!</p>
        <?php endif; ?>
        <div class="content">
            <form id="cadastroForm" action="../router.php?rota=camps" method="POST" enctype="multipart/form-data">
                <!-- Seção 2: Endereço -->
                <div class="form-section">
                    <h2><i class="fas fa-map-marker-alt"></i> Endereço</h2>
                    <div class="form-group">
                        <label for="cep" class="required"><i class="fas fa-map-pin"></i> CEP</label>
                        <div class="row">
                            <div class="col">
                                <input type="text" id="cep" name="cep" placeholder="Digite o CEP" maxlength="9" required>
                            </div>
                            <div class="col">
                                <button type="button" class="btn" id="buscarCep">
                                    <i class="fas fa-search"></i> Buscar Endereço
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="logradouro" class="required"><i class="fas fa-road"></i> Logradouro</label>
                                <input type="text" id="logradouro" name="logradouro" placeholder="Rua, Avenida, etc." required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label for="bairro" class="required"><i class="fas fa-map"></i> Bairro</label>
                                <input type="text" id="bairro" name="bairro" placeholder="Bairro" required>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label for="cidade" class="required"><i class="fas fa-city"></i> Cidade</label>
                                <input type="text" id="cidade" name="cidade" placeholder="Cidade" required>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="estado" class="required"><i class="fas fa-flag"></i> Estado</label>
                            <select id="estado" name="estado" required>
                                <option value="">Selecione um estado</option>
                                <option value="AC">Acre</option>
                                <option value="AL">Alagoas</option>
                                <option value="AP">Amapá</option>
                                <option value="AM">Amazonas</option>
                                <option value="BA">Bahia</option>
                                <option value="CE">Ceará</option>
                                <option value="DF">Distrito Federal</option>
                                <option value="ES">Espírito Santo</option>
                                <option value="GO">Goiás</option>
                                <option value="MA">Maranhão</option>
                                <option value="MT">Mato Grosso</option>
                                <option value="MS">Mato Grosso do Sul</option>
                                <option value="MG">Minas Gerais</option>
                                <option value="PA">Pará</option>
                                <option value="PB">Paraíba</option>
                                <option value="PR">Paraná</option>
                                <option value="PE">Pernambuco</option>
                                <option value="PI">Piauí</option>
                                <option value="RJ">Rio de Janeiro</option>
                                <option value="RN">Rio Grande do Norte</option>
                                <option value="RS">Rio Grande do Sul</option>
                                <option value="RO">Rondônia</option>
                                <option value="RR">Roraima</option>
                                <option value="SC">Santa Catarina</option>
                                <option value="SP">São Paulo</option>
                                <option value="SE">Sergipe</option>
                                <option value="TO">Tocantins</option>
                            </select>
                    </div>
                </div>
                <!-- Seção 3: Dados do Campeonato -->
                <div class="form-section">
                    <h2><i class="fas fa-futbol"></i> Dados do Campeonato</h2>
                    <div class="form-group">
                        <label for="nome" class="required"><i class="fas fa-trophy"></i> Nome do Campeonato</label>
                        <input type="text" id="nome" name="nome" placeholder="Nome do campeonato" required>
                    </div>
                    <div class="form-group">
                        <label for="nicho" class="required"><i class="fas fa-running"></i> Modalidade Esportiva</label>
                        <select id="nicho" name="nicho" required>
                            <option value="">Selecione uma modalidade</option>
                            <option value="Futebol">Futebol</option>
                            <option value="Futsal">Futsal</option>
                            <option value="Vôlei">Vôlei</option>
                            <option value="Basquete">Basquete</option>
                            <option value="Tênis de mesa">Tênis de mesa</option>
                            <option value="Xadrez">Xadrez</option>
                        </select>
                    </div>
                </div>
                <!-- Seção 4: Dados de Acesso -->
                <div class="form-section">
                    <h2><i class="fas fa-user-shield"></i> Dados de Acesso</h2>
                    <div class="form-group">
                        <label for="nome_dono" class="required">
                            <i class="fas fa-user"></i> Nome da Empresa
                        </label>
                        <input
                            type="text"
                            id="nome_dono"
                            name="nome_dono"
                            class="form-control-plaintext input-user-data"
                            value="<?= htmlspecialchars($nome_, ENT_QUOTES, 'UTF-8') ?>"
                            readonly
                        >
                        <input
                            type="hidden"
                            name="nome_dono"
                            value="<?= htmlspecialchars($nome_, ENT_QUOTES, 'UTF-8') ?>"
                        >
                    </div>
                    <div class="form-group">
                        <label for="cnpj" class="required">
                            <i class="fas fa-id-card"></i> CNPJ
                        </label>
                        <input
                            type="text"
                            id="cnpj"
                            name="cnpj"
                            class="form-control-plaintext input-user-data"
                            value="<?= htmlspecialchars($cnpj_, ENT_QUOTES, 'UTF-8') ?>"
                            readonly
                        >
                        <input
                            type="hidden"
                            name="cnpj"
                            value="<?= htmlspecialchars($cnpj_, ENT_QUOTES, 'UTF-8') ?>"
                        >
                    </div>
                    <div class="form-group">
                        <label for="email" class="required">
                            <i class="fas fa-envelope"></i> Email
                        </label>
                        <input
                            type="text"
                            id="email"
                            name="email"
                            class="form-control-plaintext input-user-data"
                            value="<?= htmlspecialchars($email_, ENT_QUOTES, 'UTF-8') ?>"
                            readonly
                        >
                        <input
                            type="hidden"
                            name="email"
                            value="<?= htmlspecialchars($email_, ENT_QUOTES, 'UTF-8') ?>"
                        >
                    </div>
                    <div class="form-group">
                        <label for="senha" class="required"><i class="fas fa-lock"></i> Senha</label>
                        <input type="password" id="senha" name="senha" placeholder="Confirme sua senha" required>
                        <i class="fas fa-eye password-toggle" id="togglePassword"></i>
                    </div>
                    <input type="file" name="arquivo" id="arquivo" required>
                </div>
                <button type="submit" class="btn">
                    <i class="fas fa-check-circle"></i> Cadastrar Campeonato
                </button>
                <button type="button" class="btn" onclick="window.location.href='../painel.php'">
                    <i class="fas fa-arrow-left"></i> Voltar
                </button>
            </form>
            <div id="notification" class="notification"></div>
        </div>
    </div>
<script>
    document.addEventListener('DOMContentLoaded', function() {
    const cnpjInput      = document.getElementById('cnpj');
    const cepInput       = document.getElementById('cep');
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput  = document.getElementById('senha');
    const buscarCepBtn   = document.getElementById('buscarCep');
    const form           = document.getElementById('cadastroForm');
    if (!cnpjInput || !cepInput || !form) {
        console.warn('Elementos essenciais não encontrados.');
        return;
    }
    cnpjInput.addEventListener('input', function(e) {
        let pos = e.target.selectionStart;
        let v   = e.target.value.replace(/\D/g, '').slice(0,14);
        let f   = '';
        for (let i = 0; i < v.length; i++) {
        if (i === 2 || i === 5) f += '.';
        if (i === 8) f += '/';
        if (i === 12) f += '-';
        f += v[i];
        }
        e.target.value = f;
        if (f.length > v.length && [3,6,10,15].includes(pos)) pos++;
        if (f.length < v.length && [3,6,10,15].includes(pos)) pos--;
        e.target.setSelectionRange(pos, pos);
    });
    cepInput.addEventListener('input', function(e) {
        let v = e.target.value.replace(/\D/g, '').slice(0,8);
        if (v.length > 5) v = v.replace(/(\d{5})(\d)/, '$1-$2');
        e.target.value = v;
    });
    if (togglePassword && passwordInput) {
        togglePassword.addEventListener('click', function() {
        const type = passwordInput.type === 'password' ? 'text' : 'password';
        passwordInput.type = type;
        togglePassword.classList.toggle('fa-eye');
        togglePassword.classList.toggle('fa-eye-slash');
        });
    }
    if (buscarCepBtn) {
        buscarCepBtn.addEventListener('click', function() {
        const cep = cepInput.value.replace(/\D/g, '');
        if (cep.length !== 8) {
            showNotification('CEP inválido! Digite 8 números.', 'error');
            return;
        }
        showNotification('Buscando endereço…', 'success');
        fetch(`https://viacep.com.br/ws/${cep}/json/`)
            .then(r => r.json())
            .then(data => {
            if (data.erro) {
                showNotification('CEP não encontrado!', 'error');
            } else {
                document.getElementById('logradouro').value = data.logradouro || '';
                document.getElementById('bairro').value   = data.bairro   || '';
                document.getElementById('cidade').value   = data.localidade || '';
                document.getElementById('estado').value   = data.uf       || '';
                showNotification('Endereço carregado!', 'success');
            }
            })
            .catch(() => {
            showNotification('Erro ao buscar CEP.', 'error');
            });
        });
    }
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        hideNotification();
        const cnpj        = cnpjInput.value.replace(/\D/g, '');
        const empresa     = document.getElementById('nome_dono')?.value || '';
        const cepVal      = cepInput.value.replace(/\D/g, '');
        const senha       = passwordInput?.value || '';
        if (cnpj.length !== 14) {
        showNotification('CNPJ inválido! Digite 14 números.', 'error');
        return;
        }
        if (!empresa) {
        showNotification('Nome da empresa é obrigatório!', 'error');
        return;
        }
        if (cepVal.length !== 8) {
        showNotification('CEP inválido! Digite 8 números.', 'error');
        return;
        }
        if (senha.length < 6) {
        showNotification('A senha deve ter pelo menos 6 caracteres.', 'error');
        return;
        }
        this.submit();
    });
    function showNotification(msg, type) {
        const n = document.getElementById('notification');
        if (!n) return;
        n.textContent = msg;
        n.className   = `notification ${type}`;
        n.style.display = 'block';
        n.scrollIntoView({ behavior: 'smooth', block: 'center' });
        if (type === 'success') setTimeout(() => n.style.display = 'none', 5000);
    }
    function hideNotification() {
        const n = document.getElementById('notification');
        if (n) n.style.display = 'none';
    }
    document.getElementById('senha').classList.add('input-user-data');
    });
</script>
</body>
</html>