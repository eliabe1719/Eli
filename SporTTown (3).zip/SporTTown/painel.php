<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include(__DIR__ . '/models/Model.php');
$model = new Model();
$pdo = $model->getConnect();

// Obtém todos os campeonatos usando o Model
$camps = $model->getAllCamps();

require_once('configs/protected.php');

// Dados do usuário ou empresa logada
$nome = $_SESSION['usuario_nome'] ?? $_SESSION['empresa_nome'] ?? 'Nome não disponível';
$email = $_SESSION['usuario_email'] ?? $_SESSION['empresa_email'] ?? 'E-mail não disponível';
$cnpj = $_SESSION['empresa_cnpj'] ?? 'CNPJ não disponível';

// Fechar a conexão
$pdo = null;
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="Imagens/favicon.png">
    <title>Sport Town</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"  rel="stylesheet">

    <style>
        /* Reset básico */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #181818 60%, #23243a 100%);
            color: #f5f5f5;
            line-height: 1.6;
            padding-bottom: 80px; /* Espaço para navbar inferior */
            min-height: 100vh;
        }

        /* Barra de perfil */
        .profile-section {
            background: linear-gradient(135deg, #23243a 60%, #181818 100%);
            padding: 32px 0 24px 0;
            text-align: center;
            border-bottom: 1px solid rgba(255, 40, 40, 0.15);
            box-shadow: 0 4px 24px rgba(0,0,0,0.18);
        }

        .profile-section img {
            width: 64px;
            height: 64px;
            object-fit: cover;
            border-radius: 50%;
            box-shadow: 0 2px 12px rgba(255,40,40,0.12);
            border: 3px solid #fff2;
            transition: transform 0.3s ease;
        }

        .profile-section img:hover {
            transform: scale(1.1); /* Aumenta o tamanho ao passar o mouse */
        }

        .profile-section strong {
            font-size: 1.5rem;
            color: #ff1111;
            font-weight: 700;
            letter-spacing: 1px;
            display: block;
            margin-bottom: 2px;
        }
        .profile-section small, .profile-section a {
            font-size: 1rem;
            color: #e0e0e0 !important;
            opacity: 0.95;
        }

        .btn-outline-danger {
            font-size: 15px;
            padding: 7px 18px;
            border: 1.5px solid #ff1111;
            color: #ff1111;
            background: transparent;
            border-radius: 8px;
            font-weight: 600;
            transition: background 0.3s, color 0.3s;
            box-shadow: 0 2px 8px rgba(255,17,17,0.08);
        }
        .btn-outline-danger i {
            margin-right: 6px;
        }
        .btn-outline-danger:hover {
            background: #ff1111;
            color: #fff;
        }

        /* Carrossel */
        .carousel-inner img {
            object-fit: cover;
            height: 220px;
            border-radius: 18px;
            box-shadow: 0 4px 24px rgba(0,0,0,0.18);
        }
        .carousel {
            max-width: 600px;
            margin: 32px auto 0 auto;
        }

        /* Cards de campeonatos */
        .camp-card {
            background: linear-gradient(135deg, #23243a 60%, #181818 100%);
            padding: 18px 18px 12px 18px;
            border-radius: 14px;
            margin-bottom: 18px;
            box-shadow: 0 2px 16px rgba(0,0,0,0.18);
            transition: transform 0.25s, box-shadow 0.25s, border 0.25s;
            border: 1.5px solid rgba(255, 40, 40, 0.13);
        }
        .camp-card:hover {
            transform: translateY(-4px) scale(1.01);
            border-color: #ff1111;
            box-shadow: 0 6px 32px rgba(255,17,17,0.10);
        }
        .camp-card h5 {
            font-size: 1.1rem;
            margin-bottom: 4px;
            color: #ff1111;
            font-weight: 700;
        }
        .camp-card a {
            color: #ff1111;
            text-decoration: none;
        }
        .camp-card a:hover {
            text-decoration: underline;
        }
        .camp-card p {
            font-size: 0.98rem;
            color: #e0e0e0;
            margin-bottom: 2px;
            line-height: 1.3;
        }
        .camp-card small {
            font-size: 0.85rem;
            color: #b0b0b0;
        }

        /* Navegação inferior */
        .bottom-nav {
            box-shadow: 0 -4px 24px rgba(0,0,0,0.18);
            background: rgba(26,26,26,0.98);
            z-index: 1000;
            border-top: 1.5px solid rgba(255, 40, 40, 0.18);
            backdrop-filter: blur(2px);
        }

        .nav-icon {
            width: 34px;
            height: 34px;
            transition: transform 0.3s, filter 0.3s;
            filter: grayscale(100%);
        }
        .nav-icon:hover {
            transform: scale(1.13);
            filter: grayscale(0%);
        }
        .nav-link small {
            font-size: 13px;
            color: #fff;
            margin-top: 4px;
            display: block;
            transition: color 0.3s;
            font-weight: 500;
        }
        .nav-link:hover small {
            color: #ff1111;
        }
        .nav-link {
            text-decoration: none;
            color: inherit;
        }

        /* Responsividade */
        @media (max-width: 700px) {
            body {
                padding-bottom: 100px;
            }
            .carousel-inner img {
                height: 140px;
            }
            .carousel {
                max-width: 98vw;
            }
            .profile-section {
                padding: 18px 0 12px 0;
            }
            .profile-section img {
                width: 44px;
                height: 44px;
            }
            .camp-card {
                padding: 12px 8px 8px 8px;
                border-radius: 10px;
            }
            .camp-card h5 {
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>

    <!-- Perfil do Usuário -->
<header class="profile-section py-3" style="background: linear-gradient(135deg, #1c1c1c, #2c3e50); border-bottom: 1px solid rgb(255, 40, 40);">
    <div class="container">
        <div class="row align-items-center justify-content-center">
            <!-- Logo/Ícone à Esquerda -->
            <div class="col-auto">
                <img src="Imagens/favicon.png" alt="Logo" class="rounded-circle">
            </div>
            <!-- Informações Centralizadas -->
            <div class="col text-center">
                <strong class="d-block"><?= htmlspecialchars($nome) ?></strong>
                <small class="d-block mb-1">
                    <a href="mailto:<?= htmlspecialchars($email) ?>" class="text-decoration-none">
                        <?= htmlspecialchars($email) ?>
                    </a>
                </small>
                <?php if (isset($_SESSION['empresa_cnpj'])): ?>
                    <small class="d-block mb-1">
                        <a href="#" class="text-decoration-none">
                            CNPJ: <?= htmlspecialchars($cnpj) ?>
                        </a>
                    </small>
                <?php endif; ?>
            </div>
            <!-- Botão "Sair" à Direita -->
            <div class="col-auto">
                <a href="login/logout.php" class="btn btn-sm btn-outline-danger"><i class="fas fa-sign-out-alt"></i> Sair</a>
            </div>
        </div>
    </div>
</header>

    <!-- Carrossel -->
    <div id="carouselExampleSlidesOnly" class="carousel slide mt-4" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="Imagens/1.png" class="d-block w-100" alt="Slide 1">
            </div>
            <div class="carousel-item">
                <img src="Imagens/2.png" class="d-block w-100" alt="Slide 2">
            </div>
            <div class="carousel-item">
                <img src="Imagens/Zenir.jpg" class="d-block w-100" alt="Slide 3">
            </div>
        </div>
    </div>

    <!-- Lista de Campeonatos -->
    <div class="container mt-4">
        <?php if (empty($camps)): ?>
            <p class="text-center text-muted">Nenhum campeonato cadastrado.</p>
        <?php else: ?>
            <?php foreach ($camps as $camp): ?>
                <?php
                // Verifica se existe caminho de arquivo
                $webPath = $camp['target_file'] ?? '';
                
                // Caminho físico completo no servidor
                $physicalPath = $_SERVER['DOCUMENT_ROOT'] . '/SporTTown/' . $webPath;
                
                // Gera o link para a página do campeonato
                $nomeArquivo = preg_replace('/[^a-zA-Z0-9_-]/', '_', $camp['nome']);
                $link = "Corpos/{$nomeArquivo}.php";
                ?>

                <div class="camp-card">
                    <div class="row align-items-center">
                        <!-- Coluna 1 -->
                        <div class="col-md-4">
                            <h5><?= htmlspecialchars($camp['nome_dono']) ?></h5>
                            <p><?= htmlspecialchars($camp['email']) ?></p>
                            <p><?= htmlspecialchars($camp['cnpj']) ?></p>
                        </div>

                        <!-- Coluna 2 -->
                        <div class="col-md-6">
                            <h5>
                                <a href="<?= $link ?>">
                                    <?= htmlspecialchars($camp['nome']) ?>
                                </a>
                            </h5>
                            <p>
                                Nicho: <?= htmlspecialchars($camp['nicho']) ?><br>
                                Endereço: <?= htmlspecialchars($camp['logradouro']) ?>, <?= htmlspecialchars($camp['bairro']) ?><br>
                                Cidade: <?= htmlspecialchars($camp['cidade']) ?>/<?= htmlspecialchars($camp['estado']) ?>
                            </p>
                            <small>
                                Cadastrado em: <?= date('d/m/Y H:i', strtotime($camp['criado_em'])) ?>
                            </small>
                        </div>

                        <!-- Coluna 3 -->
                        <div class="col-md-2 text-end">
                            <?php if (!empty($webPath) && file_exists($physicalPath)): ?>
                                <img src="<?= htmlspecialchars($webPath) ?>" 
                                    width="100" 
                                    alt="Imagem do campeonato"
                                    style="border-radius: 8px; border: 2px solid #ff1111;">
                            <?php else: ?>
                                <span class="text-muted">Sem imagem</span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <!-- Navegação inferior -->
<nav class="bottom-nav fixed-bottom d-flex justify-content-around py-3" style="background-color: #1c1c1c; border-top: 1px solid rgba(255, 255, 255, 0.1);">
    <a href="#" class="nav-link text-center text-decoration-none">
        <div>
            <img src="Imagens/home.png" alt="Home" class="nav-icon">
        </div>
        <small class="text-white">Home</small>
    </a>
    <a href="Ações/search.php" class="nav-link text-center text-decoration-none">
        <div>
            <img src="Imagens/lupa.png" alt="Pesquisar" class="nav-icon">
        </div>
        <small class="text-white">Pesquisar</small>
    </a>
    <a href="Ações/config.php" class="nav-link text-center text-decoration-none">
        <div>
            <img src="Imagens/configuraçoes.png" alt="Ajustes" class="nav-icon">
        </div>
        <small class="text-white">Ajustes</small>
    </a>
</nav>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> 
</body>
</html>